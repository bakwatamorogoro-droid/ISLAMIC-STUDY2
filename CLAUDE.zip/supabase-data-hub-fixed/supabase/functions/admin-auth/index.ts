// Admin authentication edge function (login / verify / change_password)
// Uses bcrypt for hashing and DB-stored opaque session tokens.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import * as bcrypt from "https://deno.land/x/bcrypt@v0.4.1/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json();
    const action = body?.action as string;

    if (action === "bootstrap") {
      const hash = bcrypt.hashSync("admin123");
      await supabase.from("admin_users").upsert(
        { username: "admin", password_hash: hash },
        { onConflict: "username" }
      );
      return json({ ok: true });
    }

    if (action === "login") {
      const { username, password } = body;
      if (!username || !password) return json({ error: "Username na password vinahitajika" }, 400);

      const { data: admin } = await supabase
        .from("admin_users")
        .select("id, username, password_hash")
        .eq("username", username)
        .maybeSingle();

      if (!admin) return json({ error: "Username au password si sahihi" }, 401);

      const ok = bcrypt.compareSync(password, admin.password_hash);
      if (!ok) return json({ error: "Username au password si sahihi" }, 401);

      const token = crypto.randomUUID() + "." + crypto.randomUUID();
      const expires = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString();
      await supabase.from("admin_sessions").insert({
        admin_id: admin.id, token, expires_at: expires,
      });

      return json({ token, admin: { id: admin.id, username: admin.username } });
    }

    if (action === "verify") {
      const { token } = body;
      if (!token) return json({ valid: false });

      const { data: sess } = await supabase
        .from("admin_sessions")
        .select("admin_id, expires_at, admin_users(id, username)")
        .eq("token", token)
        .maybeSingle();

      if (!sess) return json({ valid: false });
      if (new Date(sess.expires_at).getTime() < Date.now()) {
        await supabase.from("admin_sessions").delete().eq("token", token);
        return json({ valid: false });
      }
      const a = (sess as any).admin_users;
      return json({ valid: true, admin: { id: a.id, username: a.username } });
    }

    if (action === "change_password") {
      const { token, currentPassword, newPassword } = body;
      if (!token || !currentPassword || !newPassword) return json({ error: "Taarifa hazijakamilika" }, 400);
      if (newPassword.length < 6) return json({ error: "Password lazima iwe na herufi 6+" }, 400);

      const { data: sess } = await supabase
        .from("admin_sessions")
        .select("admin_id, expires_at")
        .eq("token", token)
        .maybeSingle();
      if (!sess || new Date(sess.expires_at).getTime() < Date.now()) {
        return json({ error: "Session imeisha" }, 401);
      }

      const { data: admin } = await supabase
        .from("admin_users")
        .select("id, username, password_hash")
        .eq("id", sess.admin_id)
        .maybeSingle();
      if (!admin) return json({ error: "Admin haipo" }, 404);

      const ok = bcrypt.compareSync(currentPassword, admin.password_hash);
      if (!ok) return json({ error: "Password ya sasa si sahihi" }, 401);

      const newHash = bcrypt.hashSync(newPassword);
      await supabase.from("admin_users").update({ password_hash: newHash }).eq("id", admin.id);

      // Invalidate other sessions, issue a fresh token
      await supabase.from("admin_sessions").delete().eq("admin_id", admin.id);
      const fresh = crypto.randomUUID() + "." + crypto.randomUUID();
      await supabase.from("admin_sessions").insert({
        admin_id: admin.id, token: fresh,
        expires_at: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(),
      });
      return json({ ok: true, token: fresh });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (e) {
    console.error("admin-auth error:", e);
    return json({ error: (e as Error).message || "Server error" }, 500);
  }
});
