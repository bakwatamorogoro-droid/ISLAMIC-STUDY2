// Short-answer grader using Lovable AI Gateway.
// Returns { awarded: number, correct: boolean }.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { question, correctAnswer, studentAnswer, marks } = await req.json();
    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!apiKey) return json({ error: "missing-key", awarded: 0, correct: false }, 500);

    const prompt = `You are grading a short-answer exam question.
Question: ${question}
Correct answer: ${correctAnswer}
Student answer: ${studentAnswer}
Max marks: ${marks}

Award marks based on conceptual correctness (not exact wording). Respond strictly as JSON: {"awarded": <number 0..${marks}>, "correct": <true|false>}.`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!res.ok) return json({ error: "ai-fail", awarded: 0, correct: false }, 200);
    const data = await res.json();
    const text: string = data?.choices?.[0]?.message?.content ?? "";
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return json({ error: "no-json", awarded: 0, correct: false });
    const parsed = JSON.parse(m[0]);
    return json({
      awarded: Math.max(0, Math.min(marks, Number(parsed.awarded) || 0)),
      correct: !!parsed.correct,
    });
  } catch (e) {
    return json({ error: (e as Error).message, awarded: 0, correct: false });
  }
});
