-- Device lock per exam per student
CREATE TABLE IF NOT EXISTS public.exam_device_locks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL,
  reg_no text NOT NULL,
  device_fingerprint text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (exam_id, reg_no)
);

ALTER TABLE public.exam_device_locks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public read exam_device_locks" ON public.exam_device_locks FOR SELECT USING (true);
CREATE POLICY "public write exam_device_locks" ON public.exam_device_locks FOR INSERT WITH CHECK (true);
CREATE POLICY "public update exam_device_locks" ON public.exam_device_locks FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "public delete exam_device_locks" ON public.exam_device_locks FOR DELETE USING (true);

CREATE INDEX IF NOT EXISTS exam_device_locks_lookup_idx ON public.exam_device_locks (exam_id, lower(reg_no));

-- Toggles on exams
ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS device_lock_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS camera_required boolean NOT NULL DEFAULT false;