CREATE TABLE public.exam_marks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_id uuid NOT NULL,
  full_name text NOT NULL,
  reg_no text NOT NULL,
  test1 numeric,
  test2 numeric,
  presentation numeric,
  contribution numeric,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (exam_id, reg_no)
);

ALTER TABLE public.exam_marks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view exam_marks" ON public.exam_marks FOR SELECT USING (true);
CREATE POLICY "Anyone can insert exam_marks" ON public.exam_marks FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update exam_marks" ON public.exam_marks FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete exam_marks" ON public.exam_marks FOR DELETE USING (true);

CREATE INDEX exam_marks_exam_id_idx ON public.exam_marks (exam_id);