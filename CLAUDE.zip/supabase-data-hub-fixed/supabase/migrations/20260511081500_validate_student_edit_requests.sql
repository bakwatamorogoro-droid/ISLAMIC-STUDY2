-- Backend validation: hakikisha submitted_reg_no na requested fields
-- haziwezi kuwa tupu au batili hata kama frontend imepita.

-- 1) Safisha data iliyopo (kama kuna NULL/blank, weka placeholder ili CHECK isifeli)
UPDATE public.student_edit_requests
SET submitted_reg_no = COALESCE(NULLIF(btrim(submitted_reg_no), ''), 'UNKNOWN')
WHERE submitted_reg_no IS NULL OR btrim(submitted_reg_no) = '';

UPDATE public.student_edit_requests
SET requested_reg_no = COALESCE(NULLIF(btrim(requested_reg_no), ''), 'UNKNOWN')
WHERE requested_reg_no IS NULL OR btrim(requested_reg_no) = '';

UPDATE public.student_edit_requests
SET requested_full_name = COALESCE(NULLIF(btrim(requested_full_name), ''), 'UNKNOWN')
WHERE requested_full_name IS NULL OR btrim(requested_full_name) = '';

-- 2) Lazimisha NOT NULL (ilikuwa tayari, lakini tunarudia kuwa salama)
ALTER TABLE public.student_edit_requests
  ALTER COLUMN submitted_reg_no SET NOT NULL,
  ALTER COLUMN requested_reg_no SET NOT NULL,
  ALTER COLUMN requested_full_name SET NOT NULL;

-- 3) CHECK constraints — kataa string tupu/whitespace na herufi pungufu
ALTER TABLE public.student_edit_requests
  DROP CONSTRAINT IF EXISTS student_edit_requests_submitted_reg_no_chk,
  DROP CONSTRAINT IF EXISTS student_edit_requests_requested_reg_no_chk,
  DROP CONSTRAINT IF EXISTS student_edit_requests_requested_full_name_chk;

ALTER TABLE public.student_edit_requests
  ADD CONSTRAINT student_edit_requests_submitted_reg_no_chk
    CHECK (char_length(btrim(submitted_reg_no)) BETWEEN 3 AND 64),
  ADD CONSTRAINT student_edit_requests_requested_reg_no_chk
    CHECK (char_length(btrim(requested_reg_no)) BETWEEN 3 AND 64),
  ADD CONSTRAINT student_edit_requests_requested_full_name_chk
    CHECK (char_length(btrim(requested_full_name)) BETWEEN 2 AND 200);

-- 4) Trigger ya kusafisha + kuthibitisha kabla ya INSERT/UPDATE
CREATE OR REPLACE FUNCTION public.validate_student_edit_request()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- trim na uppercase reg numbers
  NEW.submitted_reg_no := upper(btrim(COALESCE(NEW.submitted_reg_no, '')));
  NEW.requested_reg_no := upper(btrim(COALESCE(NEW.requested_reg_no, '')));
  NEW.requested_full_name := btrim(COALESCE(NEW.requested_full_name, ''));

  IF NEW.submitted_reg_no = '' THEN
    RAISE EXCEPTION 'submitted_reg_no haiwezi kuwa tupu' USING ERRCODE = '22023';
  END IF;
  IF NEW.requested_reg_no = '' THEN
    RAISE EXCEPTION 'requested_reg_no haiwezi kuwa tupu' USING ERRCODE = '22023';
  END IF;
  IF NEW.requested_full_name = '' THEN
    RAISE EXCEPTION 'requested_full_name haiwezi kuwa tupu' USING ERRCODE = '22023';
  END IF;

  -- Format rahisi: alphanumeric + hyphen/slash/space tu (zuia injection / junk)
  IF NEW.submitted_reg_no !~ '^[A-Z0-9][A-Z0-9 /_-]{2,63}$' THEN
    RAISE EXCEPTION 'submitted_reg_no ina muundo batili: %', NEW.submitted_reg_no
      USING ERRCODE = '22023';
  END IF;
  IF NEW.requested_reg_no !~ '^[A-Z0-9][A-Z0-9 /_-]{2,63}$' THEN
    RAISE EXCEPTION 'requested_reg_no ina muundo batili: %', NEW.requested_reg_no
      USING ERRCODE = '22023';
  END IF;

  -- Status lazima iwe moja ya thamani halali
  IF NEW.status IS NULL OR NEW.status NOT IN ('pending','approved','rejected') THEN
    NEW.status := 'pending';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_validate_student_edit_request ON public.student_edit_requests;
CREATE TRIGGER trg_validate_student_edit_request
  BEFORE INSERT OR UPDATE ON public.student_edit_requests
  FOR EACH ROW EXECUTE FUNCTION public.validate_student_edit_request();
