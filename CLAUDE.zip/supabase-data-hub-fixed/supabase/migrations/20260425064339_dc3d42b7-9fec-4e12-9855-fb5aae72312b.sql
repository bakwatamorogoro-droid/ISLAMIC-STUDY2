
ALTER TABLE public.groups
  ADD COLUMN IF NOT EXISTS student_limit integer;

ALTER TABLE public.group_members
  ADD COLUMN IF NOT EXISTS presentation_doc numeric;
