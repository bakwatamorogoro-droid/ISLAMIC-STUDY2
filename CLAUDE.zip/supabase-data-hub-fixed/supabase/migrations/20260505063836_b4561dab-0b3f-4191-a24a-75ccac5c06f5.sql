CREATE TABLE public.attendance_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  session_date date NOT NULL DEFAULT CURRENT_DATE,
  location_lat double precision,
  location_lng double precision,
  location_radius_m integer NOT NULL DEFAULT 50,
  location_required boolean NOT NULL DEFAULT true,
  is_open boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.attendance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.attendance_sessions(id) ON DELETE CASCADE,
  reg_no text NOT NULL,
  full_name text NOT NULL,
  course text,
  confirmed_at timestamptz NOT NULL DEFAULT now(),
  lat double precision,
  lng double precision,
  distance_m numeric,
  UNIQUE(session_id, reg_no)
);

ALTER TABLE public.attendance_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view attendance_sessions" ON public.attendance_sessions FOR SELECT USING (true);
CREATE POLICY "Anyone can insert attendance_sessions" ON public.attendance_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update attendance_sessions" ON public.attendance_sessions FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete attendance_sessions" ON public.attendance_sessions FOR DELETE USING (true);

CREATE POLICY "Anyone can view attendance_records" ON public.attendance_records FOR SELECT USING (true);
CREATE POLICY "Anyone can insert attendance_records" ON public.attendance_records FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update attendance_records" ON public.attendance_records FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete attendance_records" ON public.attendance_records FOR DELETE USING (true);

CREATE INDEX idx_attendance_records_session ON public.attendance_records(session_id);