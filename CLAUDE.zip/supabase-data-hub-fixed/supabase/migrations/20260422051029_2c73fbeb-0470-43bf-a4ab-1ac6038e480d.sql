-- Fix questions type check to allow long_answer
ALTER TABLE public.questions DROP CONSTRAINT IF EXISTS questions_question_type_check;
ALTER TABLE public.questions ADD CONSTRAINT questions_question_type_check
  CHECK (question_type IN ('mcq', 'short_answer', 'long_answer'));

-- Add scheduled start to exams for countdown
ALTER TABLE public.exams
  ADD COLUMN IF NOT EXISTS scheduled_start_at timestamp with time zone;

-- Announcements table
CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active announcements" ON public.announcements
  FOR SELECT TO public USING (is_active = true);
CREATE POLICY "Anyone can view all announcements" ON public.announcements
  FOR SELECT TO public USING (true);
CREATE POLICY "Anyone can insert announcements" ON public.announcements
  FOR INSERT TO public WITH CHECK (true);
CREATE POLICY "Anyone can update announcements" ON public.announcements
  FOR UPDATE TO public USING (true);
CREATE POLICY "Anyone can delete announcements" ON public.announcements
  FOR DELETE TO public USING (true);