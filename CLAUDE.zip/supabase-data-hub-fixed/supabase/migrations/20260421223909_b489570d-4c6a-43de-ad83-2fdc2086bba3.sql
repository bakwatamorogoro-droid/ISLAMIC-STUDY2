-- Admins table (username + password)
CREATE TABLE public.admins (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Exams
CREATE TABLE public.exams (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  duration_seconds INTEGER NOT NULL DEFAULT 1800,
  is_active BOOLEAN NOT NULL DEFAULT true,
  shuffle_questions BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Questions
CREATE TABLE public.questions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  question_text TEXT NOT NULL,
  question_type TEXT NOT NULL CHECK (question_type IN ('mcq','short_answer')),
  options JSONB,
  correct_answer TEXT NOT NULL,
  marks INTEGER NOT NULL DEFAULT 1,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Students
CREATE TABLE public.students (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name TEXT NOT NULL,
  exam_number TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Attempts
CREATE TABLE public.attempts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  exam_id UUID NOT NULL REFERENCES public.exams(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  submitted_at TIMESTAMPTZ,
  score NUMERIC,
  total_marks INTEGER,
  status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted','auto_submitted','terminated')),
  violation_reason TEXT,
  question_order JSONB
);

-- Answers
CREATE TABLE public.answers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  attempt_id UUID NOT NULL REFERENCES public.attempts(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  answer_text TEXT,
  is_correct BOOLEAN,
  UNIQUE(attempt_id, question_id)
);

-- Enable RLS
ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;

-- Admins: NO client access (managed via edge functions only)

-- Exams: anyone can read active exams; admin writes via edge function (service role bypasses RLS)
CREATE POLICY "Anyone can view active exams" ON public.exams
  FOR SELECT USING (is_active = true);

-- Questions: anyone can read questions of active exams (needed to take exam)
CREATE POLICY "Anyone can view questions of active exams" ON public.questions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.exams e WHERE e.id = questions.exam_id AND e.is_active = true)
  );

-- Students: anyone can register and look themselves up by exam_number
CREATE POLICY "Anyone can register as student" ON public.students
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can view students" ON public.students
  FOR SELECT USING (true);

-- Attempts: anyone can create / read / update their own attempt records
CREATE POLICY "Anyone can create attempts" ON public.attempts
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can view attempts" ON public.attempts
  FOR SELECT USING (true);
CREATE POLICY "Anyone can update attempts" ON public.attempts
  FOR UPDATE USING (true);

-- Answers: anyone can insert/read/update answers
CREATE POLICY "Anyone can insert answers" ON public.answers
  FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can view answers" ON public.answers
  FOR SELECT USING (true);
CREATE POLICY "Anyone can update answers" ON public.answers
  FOR UPDATE USING (true);

-- Seed default admin: username=admin, password=admin123 (sha256 hash, salt-less for simplicity)
-- Hash of "admin123" using sha256: 240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
INSERT INTO public.admins (username, password_hash)
VALUES ('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');