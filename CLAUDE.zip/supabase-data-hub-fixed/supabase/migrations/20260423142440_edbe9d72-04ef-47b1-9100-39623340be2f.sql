-- Semesters table
CREATE TABLE public.semesters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.semesters ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view semesters" ON public.semesters FOR SELECT USING (true);
CREATE POLICY "Anyone can insert semesters" ON public.semesters FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update semesters" ON public.semesters FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete semesters" ON public.semesters FOR DELETE USING (true);

-- Groups table
CREATE TABLE public.groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  semester_id uuid NOT NULL REFERENCES public.semesters(id) ON DELETE CASCADE,
  group_number integer NOT NULL,
  title text,
  max_score numeric NOT NULL DEFAULT 20,
  group_score numeric,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (semester_id, group_number)
);

ALTER TABLE public.groups ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view groups" ON public.groups FOR SELECT USING (true);
CREATE POLICY "Anyone can insert groups" ON public.groups FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update groups" ON public.groups FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete groups" ON public.groups FOR DELETE USING (true);

CREATE INDEX idx_groups_semester ON public.groups(semester_id);

-- Group members table
CREATE TABLE public.group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.groups(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  reg_no text NOT NULL,
  mobile_no text,
  individual_score numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view group_members" ON public.group_members FOR SELECT USING (true);
CREATE POLICY "Anyone can insert group_members" ON public.group_members FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update group_members" ON public.group_members FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete group_members" ON public.group_members FOR DELETE USING (true);

CREATE INDEX idx_group_members_group ON public.group_members(group_id);
CREATE INDEX idx_group_members_reg_no ON public.group_members(reg_no);