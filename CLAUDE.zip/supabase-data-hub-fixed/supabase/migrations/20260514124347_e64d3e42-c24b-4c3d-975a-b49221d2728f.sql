-- Consolidate home_settings to a single row (keep latest, delete duplicates)
DELETE FROM public.home_settings
WHERE id NOT IN (
  SELECT id FROM public.home_settings ORDER BY updated_at DESC NULLS LAST LIMIT 1
);