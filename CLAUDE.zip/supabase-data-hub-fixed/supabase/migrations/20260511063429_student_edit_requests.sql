-- Allow student-initiated edit requests + admin gating
ALTER TABLE public.home_settings
  ADD COLUMN IF NOT EXISTS allow_student_edits boolean NOT NULL DEFAULT true;

CREATE TABLE IF NOT EXISTS public.student_edit_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NULL REFERENCES public.students(id) ON DELETE SET NULL,
  submitted_reg_no text NOT NULL,
  submitted_full_name text NULL,
  current_full_name text NULL,
  current_reg_no text NULL,
  requested_full_name text NOT NULL,
  requested_reg_no text NOT NULL,
  reason text NULL,
  score_snapshot numeric NULL,
  total_snapshot numeric NULL,
  status text NOT NULL DEFAULT 'pending',
  admin_notes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  reviewed_at timestamptz NULL
);

CREATE INDEX IF NOT EXISTS student_edit_requests_status_idx
  ON public.student_edit_requests (status, created_at DESC);

ALTER TABLE public.student_edit_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert edit requests"
  ON public.student_edit_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can view edit requests"
  ON public.student_edit_requests FOR SELECT USING (true);
CREATE POLICY "Anyone can update edit requests"
  ON public.student_edit_requests FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete edit requests"
  ON public.student_edit_requests FOR DELETE USING (true);
