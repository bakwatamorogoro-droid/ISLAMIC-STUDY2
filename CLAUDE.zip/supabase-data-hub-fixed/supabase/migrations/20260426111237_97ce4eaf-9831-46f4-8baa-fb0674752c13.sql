-- New: seminar question papers (admin uploads, public sees on home)
CREATE TABLE IF NOT EXISTS public.seminar_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  pdf_url text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.seminar_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view seminar_questions"
  ON public.seminar_questions FOR SELECT USING (true);
CREATE POLICY "Anyone can insert seminar_questions"
  ON public.seminar_questions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update seminar_questions"
  ON public.seminar_questions FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete seminar_questions"
  ON public.seminar_questions FOR DELETE USING (true);

-- New: group submissions (students upload from home, admin reviews)
CREATE TABLE IF NOT EXISTS public.group_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_name text NOT NULL,
  semester text,
  leader_name text NOT NULL,
  leader_phone text,
  pdf_url text NOT NULL,
  notes text,
  admin_notes text,
  status text NOT NULL DEFAULT 'pending',
  reviewed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.group_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view group_submissions"
  ON public.group_submissions FOR SELECT USING (true);
CREATE POLICY "Anyone can insert group_submissions"
  ON public.group_submissions FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can update group_submissions"
  ON public.group_submissions FOR UPDATE USING (true);
CREATE POLICY "Anyone can delete group_submissions"
  ON public.group_submissions FOR DELETE USING (true);

-- Remove unused PDF columns from groups
ALTER TABLE public.groups DROP COLUMN IF EXISTS questions_pdf_url;
ALTER TABLE public.groups DROP COLUMN IF EXISTS answers_pdf_url;