ALTER TABLE public.groups
  ADD COLUMN IF NOT EXISTS location_required boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS location_lat double precision,
  ADD COLUMN IF NOT EXISTS location_lng double precision,
  ADD COLUMN IF NOT EXISTS location_radius_m integer NOT NULL DEFAULT 200;