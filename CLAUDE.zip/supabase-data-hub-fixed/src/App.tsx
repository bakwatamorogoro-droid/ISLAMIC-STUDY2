import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import StudentRegister from "./pages/StudentRegister.tsx";
import StudentSignup from "./pages/StudentSignup.tsx";
import ExamInstructions from "./pages/ExamInstructions.tsx";
import ExamTake from "./pages/ExamTake.tsx";
import ExamResult from "./pages/ExamResult.tsx";
import ExamRevision from "./pages/ExamRevision.tsx";
import StudentResultLookup from "./pages/StudentResultLookup.tsx";
import AdminBlockedStudents from "./pages/AdminBlockedStudents.tsx";
import AdminLogin from "./pages/AdminLogin.tsx";
import AdminDashboard from "./pages/AdminDashboard.tsx";
import AdminQuestions from "./pages/AdminQuestions.tsx";
import AdminResults from "./pages/AdminResults.tsx";
import AdminAttemptDetail from "./pages/AdminAttemptDetail.tsx";
import AdminAnnouncements from "./pages/AdminAnnouncements.tsx";
import AdminSemesters from "./pages/AdminSemesters.tsx";
import AdminSemesterGroups from "./pages/AdminSemesterGroups.tsx";
import AdminGroupMembers from "./pages/AdminGroupMembers.tsx";
import AdminSeminarQuestions from "./pages/AdminSeminarQuestions.tsx";
import AdminGroupSubmissions from "./pages/AdminGroupSubmissions.tsx";
import AdminSeminarBrowser from "./pages/AdminSeminarBrowser.tsx";
import AdminEditRequests from "./pages/AdminEditRequests.tsx";
import AdminAttendance from "./pages/AdminAttendance.tsx";
import AdminAttendanceDetail from "./pages/AdminAttendanceDetail.tsx";
import StudentAttendance from "./pages/StudentAttendance.tsx";
import { I18nProvider } from "./lib/i18n";
import SystemLockGate from "./components/SystemLockGate";
import WhatsAppFab from "./components/WhatsAppFab";
import PageTransition from "./components/PageTransition";


const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <I18nProvider>
    <TooltipProvider>
      <Sonner />
      <BrowserRouter>
        <SystemLockGate>
        <PageTransition>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/exam/signup" element={<StudentSignup />} />
          <Route path="/exam/register" element={<StudentRegister />} />
          <Route path="/exam/instructions" element={<ExamInstructions />} />
          <Route path="/exam/take" element={<ExamTake />} />
          <Route path="/exam/result" element={<ExamResult />} />
          <Route path="/exam/revision" element={<ExamRevision />} />
          <Route path="/admin/blocked" element={<AdminBlockedStudents />} />
          <Route path="/results" element={<StudentResultLookup />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/exams/:examId/questions" element={<AdminQuestions />} />
          <Route path="/admin/exams/:examId/results" element={<AdminResults />} />
          <Route path="/admin/attempts/:attemptId" element={<AdminAttemptDetail />} />
          <Route path="/admin/announcements" element={<AdminAnnouncements />} />
          <Route path="/admin/semesters" element={<AdminSemesters />} />
          <Route path="/admin/semesters/:semesterId/groups" element={<AdminSemesterGroups />} />
          <Route path="/admin/groups/:groupId/members" element={<AdminGroupMembers />} />
          <Route path="/admin/seminar-questions" element={<AdminSeminarQuestions />} />
          <Route path="/admin/seminar-browser" element={<AdminSeminarBrowser />} />
          <Route path="/admin/edit-requests" element={<AdminEditRequests />} />
          <Route path="/admin/submissions" element={<AdminGroupSubmissions />} />
          <Route path="/admin/attendance" element={<AdminAttendance />} />
          <Route path="/admin/attendance/:sessionId" element={<AdminAttendanceDetail />} />
          <Route path="/attendance" element={<StudentAttendance />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        </PageTransition>
        <WhatsAppFab />
        </SystemLockGate>
      </BrowserRouter>
    </TooltipProvider>
    </I18nProvider>
  </QueryClientProvider>
);

export default App;
