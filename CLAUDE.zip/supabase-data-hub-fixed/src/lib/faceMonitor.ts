// Camera face monitor — uses the browser's native FaceDetector when available.
// Gracefully degrades on unsupported browsers (no false positives).
//
// Improvements:
// - Consecutive miss buffer: lazima kukosa nyuso mara 2 mfululizo
//   kabla ya kuhesabu strike (inazuia false positives wakati wa kugeuka kidogo)
// - maxStrikes imeongezwa hadi 5 (kutoka 4)
// - Mzunguko wa ukaguzi umeongezwa kidogo (3s badala ya 4s) lakini na tolerance
//
// API:
//   const monitor = startFaceMonitor(videoEl, { onWarning, onTerminate });
//   monitor.stop();

export interface FaceMonitorOptions {
  onWarning: (kind: "no_face" | "multiple_faces", message: string, count: number) => void;
  onTerminate: (reason: string) => void;
  intervalMs?: number;
  maxStrikes?: number;
}

export interface FaceMonitorHandle {
  stop: () => void;
  supported: boolean;
}

export async function requestCameraStream(): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("Kifaa hiki hakina camera au browser haijaruhusu.");
  }
  return await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user", width: 320, height: 240 },
    audio: false,
  });
}

export function startFaceMonitor(
  video: HTMLVideoElement,
  opts: FaceMonitorOptions,
): FaceMonitorHandle {
  const interval = opts.intervalMs ?? 3000;
  const maxStrikes = opts.maxStrikes ?? 5;

  // @ts-ignore — FaceDetector is experimental, not in lib.dom
  const FD = (window as any).FaceDetector;
  const supported = typeof FD === "function";
  let stopped = false;
  let strikes = 0;

  // Consecutive miss buffer — lazima kukosa nyuso mara 2 mfululizo
  // kabla ya kuhesabu kama strike (inazuia false positives wakati wa kugeuka)
  let consecutiveMisses = 0;
  let consecutiveMultiple = 0;
  const MISS_THRESHOLD = 2;

  if (!supported) {
    return { stop: () => {}, supported: false };
  }

  // @ts-ignore
  const detector = new FD({ fastMode: false, maxDetectedFaces: 4 });

  const tick = async () => {
    if (stopped) return;

    if (video.readyState >= 2 && video.videoWidth > 0) {
      try {
        const faces: any[] = await detector.detect(video);
        const count = faces?.length ?? 0;

        if (count === 0) {
          consecutiveMultiple = 0;
          consecutiveMisses += 1;

          // Toa onyo tu baada ya kukosa mara MISS_THRESHOLD mfululizo
          if (consecutiveMisses >= MISS_THRESHOLD) {
            strikes += 1;
            consecutiveMisses = 0;
            opts.onWarning(
              "no_face",
              `Uso wako haupatikani kwenye camera. Onyo ${strikes}/${maxStrikes}.`,
              0,
            );
          }
        } else if (count > 1) {
          consecutiveMisses = 0;
          consecutiveMultiple += 1;

          if (consecutiveMultiple >= MISS_THRESHOLD) {
            strikes += 1;
            consecutiveMultiple = 0;
            opts.onWarning(
              "multiple_faces",
              `Nyuso ${count} zinaonekana — fanya peke yako. Onyo ${strikes}/${maxStrikes}.`,
              count,
            );
          }
        } else {
          // Uso mmoja tu — salama
          consecutiveMisses = 0;
          consecutiveMultiple = 0;
          if (strikes > 0) {
            strikes = Math.max(0, strikes - 0.5 as any);
          }
        }

        if (strikes >= maxStrikes) {
          stopped = true;
          opts.onTerminate("Ukiukaji wa camera (uso haupo / nyuso nyingi)");
          return;
        }
      } catch {
        // Detector inaweza kutupa wakati wa kugeuka — usihesabu kama kosa
        consecutiveMisses = 0;
      }
    }

    setTimeout(tick, interval);
  };

  // Anza baada ya sekunde 2 ili camera iwe tayari kabisa
  setTimeout(tick, 2000);

  return {
    supported: true,
    stop: () => {
      stopped = true;
    },
  };
}
