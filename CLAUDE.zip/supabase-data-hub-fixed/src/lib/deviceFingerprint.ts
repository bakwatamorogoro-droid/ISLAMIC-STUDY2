// Lightweight device fingerprint — combines stable browser/device signals
// into a hash so the same student can only take an exam from one device.
// Not a true unique ID, but stable enough to block trivial sharing.

const STORAGE_KEY = "isStudyMum_device_id";

async function sha256(s: string): Promise<string> {
  const buf = new TextEncoder().encode(s);
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function getDeviceFingerprint(): Promise<string> {
  // Stable per-browser id
  let local = localStorage.getItem(STORAGE_KEY);
  if (!local) {
    local = crypto.randomUUID();
    localStorage.setItem(STORAGE_KEY, local);
  }
  const parts = [
    local,
    navigator.userAgent || "",
    navigator.language || "",
    `${screen.width}x${screen.height}x${screen.colorDepth}`,
    String(navigator.hardwareConcurrency || 0),
    Intl.DateTimeFormat().resolvedOptions().timeZone || "",
  ];
  return await sha256(parts.join("|"));
}
