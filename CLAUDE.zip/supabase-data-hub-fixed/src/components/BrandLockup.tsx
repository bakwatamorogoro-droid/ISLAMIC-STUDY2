import { ShieldCheck, GraduationCap } from "lucide-react";
import { Link } from "react-router-dom";

interface BrandLockupProps {
  variant?: "light" | "dark";
  subtitle?: string;
  asLink?: boolean;
  className?: string;
}

/**
 * Modern, secure-looking brand lockup for ISLAMIC STUDIES MUM.
 * - Gradient logo tile with graduation cap + verified shield badge
 * - Refined display typography with subtle letter-spacing
 */
const BrandLockup = ({
  variant = "light",
  subtitle = "Islamic Studies Online Test",
  asLink = true,
  className = "",
}: BrandLockupProps) => {
  const isDark = variant === "dark";

  const Inner = (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="relative shrink-0">
        <div
          className={`h-10 w-10 rounded-xl grid place-items-center shadow-elegant ${
            isDark
              ? "bg-gradient-accent text-accent-foreground shadow-glow"
              : "bg-gradient-hero text-primary-foreground"
          }`}
        >
          <GraduationCap className="h-5 w-5" />
        </div>
        <span
          className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-emerald-500 grid place-items-center ring-2 ring-background"
          aria-hidden
        >
          <ShieldCheck className="h-3 w-3 text-white" />
        </span>
      </div>
      <div className="leading-tight min-w-0">
        <div
          className={`brand-wordmark font-extrabold tracking-tight text-[15px] md:text-base ${
            isDark ? "text-white" : "text-foreground"
          }`}
        >
          <span className="brand-word-primary">ISLAMIC</span>{" "}
          <span className="brand-word-primary">STUDIES</span>{" "}
          <span className="brand-word-accent">MUM</span>
        </div>
        <div
          className={`text-[10px] uppercase tracking-[0.18em] flex items-center gap-1 ${
            isDark ? "text-white/60" : "text-muted-foreground"
          }`}
        >
          <ShieldCheck className="h-3 w-3 text-emerald-500" />
          <span>{subtitle}</span>
        </div>
      </div>
    </div>
  );

  if (!asLink) return Inner;
  return (
    <Link to="/" className="inline-flex items-center" aria-label="ISLAMIC STUDIES MUM — Home">
      {Inner}
    </Link>
  );
};

export default BrandLockup;
