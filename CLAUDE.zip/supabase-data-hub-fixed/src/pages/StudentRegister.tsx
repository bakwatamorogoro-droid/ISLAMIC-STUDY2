import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";
import { GraduationCap, ArrowLeft, CheckCircle2, AlertTriangle } from "lucide-react";
import { getDeviceFingerprint } from "@/lib/deviceFingerprint";

interface Exam { id: string; title: string; description: string | null; duration_seconds: number; scheduled_start_at: string | null; }

const REG_NO_REGEX = /^(MUM)?\d{4}-\d{2}-?\d{3,6}$/i;

const StudentRegister = () => {
  const navigate = useNavigate();
  const [regNo, setRegNo] = useState("");
  const [examId, setExamId] = useState<string>("");
  const [exams, setExams] = useState<Exam[]>([]);
  const [member, setMember] = useState<{ id: string; full_name: string; reg_no: string } | null>(null);
  const [lookingUp, setLookingUp] = useState(false);
  const [loading, setLoading] = useState(false);
  // Matokeo ya ukaguzi wa mtihani uliopita
  const [previousExams, setPreviousExams] = useState<{ examTitle: string; status: string }[]>([]);

  useEffect(() => {
    supabase.from("exams").select("*").eq("is_active", true).then(({ data }) => {
      setExams((data as any) || []);
      if (data && data.length > 0) setExamId(data[0].id);
    });
  }, []);

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    const reg = regNo.trim().toUpperCase();
    if (!reg) return toast.error("Andika Reg No.");
    if (!REG_NO_REGEX.test(reg)) {
      return toast.error("Muundo wa Reg No si sahihi. Mifano: 2021-04-93392 au MUM2021-04578");
    }

    setLookingUp(true);
    setPreviousExams([]);
    try {
      // Angalia orodha ya waliozuiwa
      try {
        const { data: blk } = await supabase
          .from("blocked_students" as any)
          .select("reason, full_name")
          .ilike("reg_no", reg)
          .maybeSingle();
        if (blk) {
          toast.error(`🚫 Umezuiwa kufanya mtihani${(blk as any).reason ? `: ${(blk as any).reason}` : "."}`);
          return;
        }
      } catch {}

      const { data } = await supabase
        .from("group_members")
        .select("id, full_name, reg_no")
        .ilike("reg_no", reg)
        .maybeSingle();

      if (!data) {
        toast.error("Reg No haijasajiliwa. Tafadhali jisajili kwanza kwenye semina.");
        return;
      }

      // --- Angalia ikiwa Reg No imeshafanya mtihani WOWOTE ---
      const { data: studentRec } = await supabase
        .from("students")
        .select("id")
        .ilike("exam_number", reg)
        .maybeSingle();

      if (studentRec) {
        const { data: doneAttempts } = await supabase
          .from("attempts")
          .select("status, exams(title)")
          .eq("student_id", studentRec.id)
          .in("status", ["submitted", "auto_submitted", "terminated"]);

        if (doneAttempts && doneAttempts.length > 0) {
          const list = doneAttempts.map((a: any) => ({
            examTitle: a.exams?.title || "—",
            status: a.status,
          }));
          setPreviousExams(list);
        }
      }
      // -------------------------------------------------------

      setMember(data);
      toast.success(`Karibu ${data.full_name}!`);
    } finally {
      setLookingUp(false);
    }
  };

  const handleStart = async () => {
    if (!member || !examId) return toast.error("Chagua mtihani.");
    const selectedExam = exams.find((x) => x.id === examId);
    if (selectedExam?.scheduled_start_at) {
      const startMs = new Date(selectedExam.scheduled_start_at).getTime();
      if (Date.now() < startMs) {
        const when = new Date(startMs).toLocaleString();
        toast.error(`Subiri muda ulioweka uanze mtihani. Mtihani utaanza ${when}.`);
        return;
      }
    }
    setLoading(true);
    try {
      let { data: existing } = await supabase
        .from("students")
        .select("id")
        .eq("exam_number", member.reg_no)
        .maybeSingle();

      let studentId = existing?.id;
      if (!studentId) {
        const { data: newS, error } = await supabase
          .from("students")
          .insert({ full_name: member.full_name, exam_number: member.reg_no })
          .select("id")
          .single();
        if (error) throw error;
        studentId = newS.id;
      }

      // --- Angalia ikiwa Reg No imeshafanya mtihani HUU hasa ---
      const { data: prev } = await supabase
        .from("attempts")
        .select("id, status, exams(title)")
        .eq("student_id", studentId)
        .eq("exam_id", examId)
        .maybeSingle();

      if (prev) {
        if (prev.status === "in_progress") {
          // Ruhusu kuendelea na mtihani uliopo
          // (fall through to device check)
        } else {
          // Amekamilisha mtihani huu tayari
          const examTitle = (prev as any).exams?.title || selectedExam?.title || "mtihani huu";
          toast.error(
            `🚫 Reg No "${member.reg_no}" imeshafanya "${examTitle}". Haiwezekani kufanya tena.`,
            { duration: 8000 }
          );
          setLoading(false);
          return;
        }
      }

      // --- Device Lock: Device 1 ndiyo pekee inayoruhusiwa ---
      const examFull = exams.find((x) => x.id === examId) as any;
      const lockEnabled = examFull?.device_lock_enabled !== false;
      if (lockEnabled) {
        const fp = await getDeviceFingerprint();
        const { data: lock } = await supabase
          .from("exam_device_locks" as any)
          .select("device_fingerprint")
          .eq("exam_id", examId)
          .ilike("reg_no", member.reg_no)
          .maybeSingle();

        if (lock && (lock as any).device_fingerprint && (lock as any).device_fingerprint !== fp) {
          toast.error(
            "🚫 Reg No hii ilianza mtihani kwenye kifaa kingine. Huwezi kufanya kwenye kifaa hiki. Wasiliana na admin.",
            { duration: 8000 }
          );
          setLoading(false);
          return;
        }
        if (!lock) {
          // Sajili kifaa hiki kama Device 1
          await supabase.from("exam_device_locks" as any).insert({
            exam_id: examId,
            reg_no: member.reg_no,
            device_fingerprint: fp,
            user_agent: navigator.userAgent,
          });
        }
      }
      // -------------------------------------------------------

      sessionStorage.setItem("isStudyMum_student", JSON.stringify({
        studentId, examId, fullName: member.full_name, examNumber: member.reg_no
      }));
      navigate("/exam/instructions");
    } catch (err: any) {
      toast.error(err.message || "Hitilafu imetokea.");
    } finally {
      setLoading(false);
    }
  };

  const statusLabel = (s: string) => {
    if (s === "submitted") return "Imekamilika";
    if (s === "auto_submitted") return "Ilitumwa otomatiki (muda)";
    if (s === "terminated") return "Ilisimamishwa (ukiukaji)";
    return s;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8">
          <ArrowLeft className="h-4 w-4" /> Rudi nyumbani
        </Link>

        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-hero items-center justify-center mb-4 text-primary-foreground shadow-elegant">
              <GraduationCap className="h-7 w-7" />
            </div>
            <h1 className="text-3xl font-extrabold mb-2">Ingia Kufanya Mtihani</h1>
            <p className="text-muted-foreground text-sm">Andika Reg No yako tu.</p>
          </div>

          <Card className="p-6 shadow-card">
            {!member ? (
              <form onSubmit={handleLookup} className="space-y-4">
                <div>
                  <Label htmlFor="reg">Reg No</Label>
                  <Input id="reg" value={regNo} onChange={(e) => setRegNo(e.target.value.toUpperCase())}
                    placeholder="MUM2021-04-06575 au 2021-04-07685" required className="font-mono-num" />
                  <p className="text-[11px] text-muted-foreground mt-1">
                    Lazima uwe umejisajiliwa tayari kwenye semina.
                  </p>
                </div>
                <Button type="submit" className="w-full" disabled={lookingUp}>
                  {lookingUp ? "Inatafuta..." : "Endelea"}
                </Button>
                <p className="text-xs text-center text-muted-foreground pt-2">
                  Hujajisajili?{" "}
                  <Link to="/exam/signup" className="text-accent font-semibold hover:underline">
                    Jisajili hapa
                  </Link>
                </p>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="p-4 rounded-xl bg-accent/5 border border-accent/20">
                  <div className="flex items-center gap-2 mb-2 text-accent">
                    <CheckCircle2 className="h-4 w-4" />
                    <span className="text-xs uppercase tracking-widest font-semibold">Taarifa zako</span>
                  </div>
                  <div className="text-sm">
                    <div><span className="text-muted-foreground">Jina:</span> <strong>{member.full_name}</strong></div>
                    <div><span className="text-muted-foreground">Reg No:</span> <strong className="font-mono-num">{member.reg_no}</strong></div>
                  </div>
                </div>

                {/* Onyo: Reg No imeshafanya mtihani(hani) nyingine */}
                {previousExams.length > 0 && (
                  <div className="p-3 rounded-xl bg-warning/10 border border-warning/30">
                    <div className="flex items-center gap-2 text-warning font-semibold text-sm mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      Reg No hii imeshafanya mtihani:
                    </div>
                    <ul className="text-xs space-y-1">
                      {previousExams.map((pe, i) => (
                        <li key={i} className="flex justify-between">
                          <span className="font-medium">{pe.examTitle}</span>
                          <span className="text-muted-foreground">{statusLabel(pe.status)}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="text-[11px] text-muted-foreground mt-2">
                      Kama unataka kufanya mtihani <em>tofauti</em>, chagua hapa chini. 
                      Mtihani uliofanywa hauwezi kufanywa tena.
                    </p>
                  </div>
                )}

                <div>
                  <Label htmlFor="exam">Chagua mtihani</Label>
                  <select id="exam" value={examId} onChange={(e) => setExamId(e.target.value)}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                    {exams.length === 0 && <option value="">Hakuna mtihani uliopo sasa</option>}
                    {exams.map((ex) => (
                      <option key={ex.id} value={ex.id}>{ex.title}</option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => { setMember(null); setRegNo(""); setPreviousExams([]); }}>Badilisha</Button>
                  <Button className="flex-1" onClick={handleStart} disabled={loading || exams.length === 0}>
                    {loading ? "Inasubiri..." : "Endelea kufanya mtihani"}
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudentRegister;
