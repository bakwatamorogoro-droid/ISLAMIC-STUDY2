// @ts-nocheck
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Save, CheckCircle2, XCircle, FileText, Sparkles, Loader2, FileSpreadsheet, FileDown } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { exportRowsToCSV } from "@/lib/exportResults";
import * as XLSX from "xlsx";
import { toast } from "sonner";

interface Question {
  id: string; question_text: string; question_type: "mcq" | "true_false" | "short_answer" | "long_answer";
  options: string[] | null; correct_answer: string; marks: number;
}
interface Answer {
  id: string; question_id: string; answer_text: string | null;
  is_correct: boolean | null; awarded_marks: number | null;
}

const AdminAttemptDetail = () => {
  const { attemptId } = useParams();
  const navigate = useNavigate();
  const [attempt, setAttempt] = useState<any>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, Answer>>({});
  const [grades, setGrades] = useState<Record<string, string>>({});
  const [aiNotes, setAiNotes] = useState<Record<string, string>>({});
  const [aiBusy, setAiBusy] = useState<Record<string, boolean>>({});
  const [aiBatch, setAiBatch] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    verifyAdmin().then(async (a) => {
      if (!a) { navigate("/admin/login"); return; }
      await load();
    });
  }, [attemptId]);

  const load = async () => {
    const { data: att } = await supabase
      .from("attempts")
      .select("*, students(full_name, exam_number), exams(title)")
      .eq("id", attemptId).single();
    setAttempt(att);
    if (!att) return;

    const { data: qs } = await supabase.from("questions").select("*").eq("exam_id", att.exam_id);
    const { data: ans } = await supabase.from("answers").select("*").eq("attempt_id", attemptId);

    const orderIds: string[] = (att.question_order as any) || (qs || []).map((q: any) => q.id);
    const qMap = new Map((qs || []).map((q: any) => [q.id, q]));
    const ordered = orderIds.map((id) => qMap.get(id)).filter(Boolean) as Question[];
    setQuestions(ordered);

    const aMap: Record<string, Answer> = {};
    const gMap: Record<string, string> = {};
    (ans || []).forEach((a: any) => {
      aMap[a.question_id] = a;
      if (a.awarded_marks !== null) gMap[a.question_id] = String(a.awarded_marks);
    });
    setAnswers(aMap);
    setGrades(gMap);
  };

  const aiGrade = async (q: Question) => {
    const a = answers[q.id];
    if (!a) return;
    setAiBusy((b) => ({ ...b, [q.id]: true }));
    try {
      const { data, error } = await supabase.functions.invoke("grade-short-answer", {
        body: {
          question: q.question_text,
          correctAnswer: q.correct_answer,
          studentAnswer: a.answer_text || "",
          marks: q.marks,
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      const awarded = Math.max(0, Math.min(q.marks, Number(data.awarded) || 0));
      setGrades((g) => ({ ...g, [q.id]: String(awarded) }));
      setAiNotes((n) => ({ ...n, [q.id]: data.reason || "" }));
      toast.success(`AI: ${awarded}/${q.marks} — ${data.correct ? "Sahihi" : "Si sahihi kabisa"}`);
    } catch (e: any) {
      toast.error(e.message || "AI grading imefeli");
    } finally {
      setAiBusy((b) => ({ ...b, [q.id]: false }));
    }
  };

  const aiGradeAllShort = async () => {
    const targets = questions.filter((q) => q.question_type === "short_answer" && answers[q.id]);
    if (targets.length === 0) return;
    setAiBatch(true);
    for (const q of targets) {
      await aiGrade(q);
    }
    setAiBatch(false);
    toast.success("AI imepima maswali yote ya jibu fupi");
  };

  const saveGrades = async () => {
    setSaving(true);
    let totalScore = 0;
    let stillNeedsGrading = false;

    for (const q of questions) {
      const a = answers[q.id];
      if (!a) continue;
      if (q.question_type === "long_answer" || q.question_type === "short_answer") {
        const v = grades[q.id];
        if (v === undefined || v === "") {
          // For short_answer fall back to auto-grade (exact match) result
          if (q.question_type === "short_answer") {
            if (a.is_correct) totalScore += q.marks;
          } else {
            stillNeedsGrading = true;
          }
          continue;
        }
        const m = Math.max(0, Math.min(q.marks, Number(v) || 0));
        await supabase.from("answers").update({
          awarded_marks: m, is_correct: m === q.marks,
        }).eq("id", a.id);
        totalScore += m;
      } else {
        // mcq auto-graded
        if (a.is_correct) totalScore += q.marks;
      }
    }

    await supabase.from("attempts").update({
      score: totalScore, needs_grading: stillNeedsGrading,
    }).eq("id", attemptId);

    setSaving(false);
    toast.success("Alama zimehifadhiwa");
    load();
  };

  if (!attempt) return null;

  const totalMax = questions.reduce((s, q) => s + q.marks, 0);
  const totalGiven = questions.reduce((s, q) => {
    const a = answers[q.id];
    if (!a) return s;
    if (q.question_type === "long_answer" || q.question_type === "short_answer") {
      if (a.awarded_marks != null) return s + Number(a.awarded_marks);
    }
    if (q.question_type === "short_answer" || q.question_type === "mcq" || q.question_type === "true_false") {
      return s + (a.is_correct ? q.marks : 0);
    }
    return s;
  }, 0);

  const hasShortAnswers = questions.some((q) => q.question_type === "short_answer");

  const essayRows = () => {
    const targets = questions.filter((q) => q.question_type === "short_answer" || q.question_type === "long_answer");
    return targets.map((q, i) => {
      const a = answers[q.id];
      const awarded = a?.awarded_marks != null ? Number(a.awarded_marks) : (a?.is_correct ? q.marks : 0);
      return {
        n: i + 1,
        type: q.question_type === "short_answer" ? "Jibu Fupi" : "Insha",
        question: q.question_text,
        correct: q.correct_answer || "",
        student: a?.answer_text || "",
        awarded, marks: q.marks,
      };
    });
  };
  const baseName = () => `${(attempt.students?.full_name || "Student").replace(/\s+/g, "_")}_${attempt.students?.exam_number || ""}_Essays`;
  const exportEssayCSV = () => {
    const rows = essayRows();
    if (!rows.length) return toast.info("Hakuna maswali ya essay.");
    exportRowsToCSV(`${baseName()}.csv`,
      ["#", "Aina", "Swali", "Jibu Sahihi", "Jibu la Mwanafunzi", "Alama", "Jumla"],
      rows.map((r) => [r.n, r.type, r.question, r.correct, r.student, r.awarded, r.marks]));
  };
  const exportEssayExcel = () => {
    const rows = essayRows();
    if (!rows.length) return toast.info("Hakuna maswali ya essay.");
    const aoa: any[][] = [
      [`${attempt.students?.full_name} — ${attempt.exams?.title} — Essays`], [],
      ["#", "Aina", "Swali", "Jibu Sahihi", "Jibu la Mwanafunzi", "Alama", "Jumla"],
    ];
    rows.forEach((r) => aoa.push([r.n, r.type, r.question, r.correct, r.student, r.awarded, r.marks]));
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 4 }, { wch: 10 }, { wch: 40 }, { wch: 30 }, { wch: 40 }, { wch: 8 }, { wch: 8 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Essays");
    XLSX.writeFile(wb, `${baseName()}.xlsx`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 max-w-4xl">
        <div className="flex items-center justify-between gap-2 flex-wrap mb-4">
          <Link to={`/admin/exams/${attempt.exam_id}/results`} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Matokeo
          </Link>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={exportEssayExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Essay Excel
            </Button>
            <Button size="sm" variant="outline" onClick={exportEssayCSV}>
              <FileDown className="h-4 w-4 mr-1" /> Essay CSV
            </Button>
          </div>
        </div>


        <Card className="p-6 mb-6 shadow-card bg-gradient-card">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <p className="text-xs uppercase tracking-widest text-muted-foreground">{attempt.exams?.title}</p>
              <h1 className="text-2xl font-extrabold">{attempt.students?.full_name}</h1>
              <p className="text-sm font-mono-num text-muted-foreground">{attempt.students?.exam_number}</p>
            </div>
            <div className="text-right">
              <div className="text-xs uppercase tracking-widest text-muted-foreground">Alama</div>
              <div className="font-mono-num text-3xl font-extrabold">{totalGiven}<span className="text-lg text-muted-foreground">/{totalMax}</span></div>
            </div>
          </div>
          {attempt.violation_reason && (
            <p className="text-sm text-warning mt-3">⚠ {attempt.violation_reason}</p>
          )}
          {hasShortAnswers && (
            <div className="mt-4 pt-4 border-t border-border flex items-center justify-between gap-3 flex-wrap">
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Sparkles className="h-3.5 w-3.5 text-accent" />
                AI inaweza kupima jibu fupi kwa <strong>idea</strong> (sio neno-kwa-neno).
              </div>
              <Button size="sm" variant="outline" onClick={aiGradeAllShort} disabled={aiBatch}>
                {aiBatch ? <><Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> AI inapima...</> : <><Sparkles className="h-3.5 w-3.5 mr-1" /> AI Grade Zote (Jibu Fupi)</>}
              </Button>
            </div>
          )}
        </Card>

        <div className="space-y-4">
          {questions.map((q, i) => {
            const a = answers[q.id];
            const studentAns = a?.answer_text || "";
            return (
              <Card key={q.id} className="p-5 shadow-card">
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2 flex-wrap">
                  <span className="px-2 py-0.5 rounded-full bg-primary/5 text-primary font-semibold">#{i + 1}</span>
                  <span className="px-2 py-0.5 rounded-full bg-muted">
                    {q.question_type === "mcq" ? "MCQ" : q.question_type === "true_false" ? "Kweli/Sio Kweli" : q.question_type === "short_answer" ? "Jibu Fupi" : "Insha"}
                  </span>
                  <span>Alama: {q.marks}</span>
                  {q.question_type !== "long_answer" && (
                    a?.is_correct
                      ? <span className="inline-flex items-center gap-1 text-accent font-semibold"><CheckCircle2 className="h-3.5 w-3.5" /> Sahihi</span>
                      : <span className="inline-flex items-center gap-1 text-destructive font-semibold"><XCircle className="h-3.5 w-3.5" /> Si Sahihi</span>
                  )}
                </div>
                <p className="font-semibold mb-3">{q.question_text}</p>

                {(q.question_type === "mcq" || q.question_type === "true_false") && q.options && (
                  <ul className="text-sm space-y-1 mb-3">
                    {q.options.map((o, idx) => {
                      const isStudent = o === studentAns;
                      const isCorrect = o === q.correct_answer;
                      return (
                        <li key={idx} className={`flex items-center gap-2 ${isCorrect ? "text-accent font-semibold" : isStudent ? "text-destructive" : "text-muted-foreground"}`}>
                          <span className="font-bold w-5">{String.fromCharCode(65 + idx)}.</span>
                          <span>{o}</span>
                          {isStudent && <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-muted">Mwanafunzi</span>}
                          {isCorrect && <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-accent/15">Sahihi</span>}
                        </li>
                      );
                    })}
                  </ul>
                )}

                {q.question_type !== "mcq" && q.question_type !== "true_false" && (
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1">Jibu la Mwanafunzi</p>
                      <div className="p-3 rounded-lg bg-muted/40 border border-border whitespace-pre-wrap text-sm min-h-[3rem]">
                        {studentAns || <span className="text-muted-foreground italic">— Hakujibu —</span>}
                      </div>
                    </div>
                    {q.question_type === "short_answer" && (
                      <>
                        <div className="text-sm"><span className="text-muted-foreground">Jibu sahihi (key): </span>
                          <span className="font-semibold text-accent">{q.correct_answer}</span></div>
                        {aiNotes[q.id] && (
                          <div className="text-xs p-2 rounded-lg bg-accent/5 border border-accent/20 text-foreground/80 flex gap-2">
                            <Sparkles className="h-3.5 w-3.5 text-accent shrink-0 mt-0.5" />
                            <span><strong className="text-accent">AI:</strong> {aiNotes[q.id]}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-2 flex-wrap">
                          <Button type="button" size="sm" variant="outline" onClick={() => aiGrade(q)} disabled={!!aiBusy[q.id]}>
                            {aiBusy[q.id] ? <><Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> AI...</> : <><Sparkles className="h-3.5 w-3.5 mr-1" /> AI Grade</>}
                          </Button>
                          <label className="text-sm font-semibold ml-2">Alama:</label>
                          <Input
                            type="number" min={0} max={q.marks}
                            value={grades[q.id] ?? ""}
                            onChange={(e) => setGrades({ ...grades, [q.id]: e.target.value })}
                            className="w-24 font-mono-num"
                            placeholder={a?.is_correct ? String(q.marks) : "0"}
                          />
                          <span className="text-sm text-muted-foreground">/ {q.marks}</span>
                        </div>
                      </>
                    )}
                    {q.question_type === "long_answer" && (
                      <>
                        {q.correct_answer && q.correct_answer !== "[Manual grading]" && (
                          <div className="text-sm">
                            <p className="text-muted-foreground mb-1">Mwongozo:</p>
                            <p className="text-muted-foreground italic">{q.correct_answer}</p>
                          </div>
                        )}
                        <div className="flex items-center gap-3">
                          <label className="text-sm font-semibold">Toa Alama:</label>
                          <Input
                            type="number" min={0} max={q.marks}
                            value={grades[q.id] ?? ""}
                            onChange={(e) => setGrades({ ...grades, [q.id]: e.target.value })}
                            className="w-24 font-mono-num"
                            placeholder="0"
                          />
                          <span className="text-sm text-muted-foreground">/ {q.marks}</span>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>

        {questions.some((q) => q.question_type === "long_answer" || q.question_type === "short_answer") && (
          <div className="sticky bottom-4 mt-6">
            <Button onClick={saveGrades} disabled={saving} size="lg" className="w-full shadow-elegant">
              <Save className="h-4 w-4 mr-2" /> {saving ? "Inahifadhi..." : "Hifadhi Alama"}
            </Button>
          </div>
        )}

        {questions.length === 0 && (
          <Card className="p-12 text-center text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Hakuna majibu yaliyopatikana.
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminAttemptDetail;
