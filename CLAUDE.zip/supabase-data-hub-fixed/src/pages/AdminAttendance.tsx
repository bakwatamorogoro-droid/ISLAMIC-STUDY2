import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Plus, MapPin, Crosshair, Users, Lock, Unlock, Trash2, Eye } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { getCurrentPosition } from "@/lib/geo";
import { toast } from "sonner";

interface Session {
  id: string; title: string; session_date: string;
  location_lat: number | null; location_lng: number | null;
  location_radius_m: number; location_required: boolean;
  is_open: boolean; notes: string | null; created_at: string;
}

const AdminAttendance = () => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [showForm, setShowForm] = useState(false);

  const [title, setTitle] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [lat, setLat] = useState(""); const [lng, setLng] = useState("");
  const [radius, setRadius] = useState(50);
  const [locReq, setLocReq] = useState(true);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    verifyAdmin().then((a) => { if (!a) navigate("/admin/login"); else load(); });
  }, []);

  const load = async () => {
    const { data } = await supabase.from("attendance_sessions" as any).select("*").order("session_date", { ascending: false });
    const list = (data as any) || [];
    setSessions(list);
    if (list.length) {
      const { data: recs } = await supabase.from("attendance_records" as any)
        .select("session_id").in("session_id", list.map((s: Session) => s.id));
      const c: Record<string, number> = {};
      ((recs as any) || []).forEach((r: any) => { c[r.session_id] = (c[r.session_id] || 0) + 1; });
      setCounts(c);
    }
  };

  const useMyLocation = async () => {
    try {
      const p = await getCurrentPosition(20000);
      setLat(p.lat.toFixed(6)); setLng(p.lng.toFixed(6));
      toast.success(`Location set (±${Math.round(p.accuracy)}m)`);
    } catch (e: any) { toast.error(e.message); }
  };

  const create = async () => {
    if (!title.trim()) return toast.error("Weka jina la kipindi");
    if (locReq && (!lat || !lng)) return toast.error("Weka GPS au zima 'GPS Required'");
    const { error } = await supabase.from("attendance_sessions" as any).insert({
      title: title.trim(), session_date: date,
      location_lat: lat ? Number(lat) : null, location_lng: lng ? Number(lng) : null,
      location_radius_m: radius, location_required: locReq, notes: notes || null, is_open: false,
    });
    if (error) return toast.error(error.message);
    toast.success("Kipindi kimeundwa");
    setTitle(""); setNotes(""); setLat(""); setLng(""); setShowForm(false);
    load();
  };

  const toggleOpen = async (s: Session) => {
    const { error } = await supabase.from("attendance_sessions" as any).update({ is_open: !s.is_open }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success(!s.is_open ? "Kimewashwa — wanafunzi wanaweza kuthibitisha" : "Kimezimwa");
    load();
  };

  const remove = async (s: Session) => {
    if (!confirm(`Futa kipindi "${s.title}" pamoja na rekodi zote?`)) return;
    const { error } = await supabase.from("attendance_sessions" as any).delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Admin
        </Link>
        <div className="flex items-start justify-between gap-3 flex-wrap mb-6">
          <div>
            <h1 className="text-2xl font-extrabold">Attendance — Wanafunzi Online</h1>
            <p className="text-sm text-muted-foreground">Tengeneza kipindi, washa, mwanafunzi athibitishe kwa GPS akiwa darasani / tent.</p>
          </div>
          <Button onClick={() => setShowForm((s) => !s)}><Plus className="h-4 w-4 mr-1" /> Kipindi Kipya</Button>
        </div>

        {showForm && (
          <Card className="p-5 mb-6 shadow-card">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Jina la Kipindi / Semina</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Mfano: Semina ya Tafsir — Wiki 1" />
              </div>
              <div>
                <Label>Tarehe</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
              <div className="md:col-span-2 flex items-center gap-3 pt-1">
                <Switch checked={locReq} onCheckedChange={setLocReq} />
                <span className="text-sm font-semibold">GPS Required (lazima awe darasani / tent)</span>
              </div>
              {locReq && (
                <>
                  <div>
                    <Label>Latitude</Label>
                    <Input value={lat} onChange={(e) => setLat(e.target.value)} placeholder="-6.7924" />
                  </div>
                  <div>
                    <Label>Longitude</Label>
                    <Input value={lng} onChange={(e) => setLng(e.target.value)} placeholder="39.2083" />
                  </div>
                  <div>
                    <Label>Radius (mita)</Label>
                    <Input type="number" value={radius} onChange={(e) => setRadius(Number(e.target.value) || 50)} />
                  </div>
                  <div className="flex items-end">
                    <Button type="button" variant="outline" onClick={useMyLocation} className="w-full">
                      <Crosshair className="h-4 w-4 mr-1" /> Tumia eneo langu
                    </Button>
                  </div>
                </>
              )}
              <div className="md:col-span-2">
                <Label>Maelezo (hiari)</Label>
                <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={create}>Hifadhi</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Ghairi</Button>
            </div>
          </Card>
        )}

        {sessions.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Hakuna vipindi bado.
          </Card>
        ) : (
          <div className="grid gap-3">
            {sessions.map((s) => (
              <Card key={s.id} className="p-4 shadow-card flex items-center justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-bold">{s.title}</h3>
                    {s.is_open
                      ? <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-accent/15 text-accent font-bold">OPEN</span>
                      : <span className="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full bg-muted text-muted-foreground font-bold">CLOSED</span>}
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-3 flex-wrap mt-1">
                    <span>📅 {s.session_date}</span>
                    {s.location_required && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> {s.location_radius_m}m</span>}
                    <span className="font-semibold text-foreground">👥 {counts[s.id] || 0} waliothibitisha</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant={s.is_open ? "destructive" : "default"} onClick={() => toggleOpen(s)}>
                    {s.is_open ? <><Lock className="h-3.5 w-3.5 mr-1" /> Zima</> : <><Unlock className="h-3.5 w-3.5 mr-1" /> Washa</>}
                  </Button>
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/admin/attendance/${s.id}`}><Eye className="h-3.5 w-3.5 mr-1" /> Orodha</Link>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(s)} className="text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminAttendance;
