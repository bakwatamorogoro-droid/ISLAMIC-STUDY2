// @ts-nocheck
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, FileSpreadsheet, FileDown, Users, Upload } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

const REG_NO_REGEX = /^(MUM)?\d{4}-\d{2}-?\d{3,6}$/i;

// Coursework component fields editable per student
type Field = "test1" | "test2" | "presentation" | "presentation_doc" | "contribution" | "attendance" | "quiz" | "university_exam";

const num = (v: any): number => (v === null || v === undefined || v === "" ? 0 : Number(v) || 0);

// Coursework total per template:
// = PRESENTATION + PRE.DOC + (TEST1/20*15) + (TEST2/20*15) + ATTENDANCE + CONTRIBUTION + QUIZ
const courseworkTotal = (m: any) =>
  num(m.presentation) + num(m.presentation_doc) +
  (num(m.test1) / 20) * 15 + (num(m.test2) / 20) * 15 +
  num(m.attendance) + num(m.contribution) + num(m.quiz);

// University exam capped at 60
const uniExam = (m: any) => Math.min(60, num(m.university_exam));

const grandTotal = (m: any) => courseworkTotal(m) + uniExam(m);

const remarkOf = (m: any) => {
  const fields: Field[] = ["test1", "test2", "presentation", "presentation_doc", "contribution", "attendance", "quiz", "university_exam"];
  const anyMissing = fields.some((f) => m[f] === null || m[f] === undefined || m[f] === "");
  return anyMissing ? "INCOMPLETE" : "DONE";
};

const AdminGroupMembers = () => {
  const { groupId } = useParams();
  const navigate = useNavigate();
  const [group, setGroup] = useState<any>(null);
  const [semester, setSemester] = useState<any>(null);
  const [members, setMembers] = useState<any[]>([]);
  const [fullName, setFullName] = useState("");
  const [regNo, setRegNo] = useState("");
  const [mobile, setMobile] = useState("");
  const [gender, setGender] = useState("");
  const [course, setCourse] = useState("");

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [groupId]);

  const load = async () => {
    const { data: g } = await supabase.from("groups").select("*").eq("id", groupId).single();
    setGroup(g);
    if (g) {
      const { data: s } = await supabase.from("semesters").select("*").eq("id", g.semester_id).single();
      setSemester(s);
    }
    const { data: ms } = await supabase.from("group_members").select("*").eq("group_id", groupId).order("created_at");
    setMembers(ms || []);
  };

  const addMember = async (e: React.FormEvent) => {
    e.preventDefault();
    const reg = regNo.trim().toUpperCase();
    if (!fullName.trim() || !reg) return toast.error("Jaza jina na reg no");
    if (!REG_NO_REGEX.test(reg)) {
      return toast.error("Muundo wa Reg No si sahihi. Mifano: 2021-04-93392 au MUM2021-04578");
    }
    const { error } = await supabase.from("group_members").insert({
      group_id: groupId,
      full_name: fullName.trim(),
      reg_no: reg,
      mobile_no: mobile.trim() || null,
      gender: gender || null,
      course: course.trim() || null,
    });
    if (error) return toast.error(error.message);
    toast.success("Mwanafunzi ameongezwa");
    setFullName(""); setRegNo(""); setMobile(""); setGender(""); setCourse("");
    load();
  };

  const updateField = async (id: string, field: Field, value: string) => {
    const v = value === "" ? null : parseFloat(value);
    const patch: any = { [field]: v };
    const { error } = await supabase.from("group_members").update(patch).eq("id", id);
    if (error) return toast.error(error.message);
    setMembers(members.map((m) => m.id === id ? { ...m, ...patch } : m));
  };

  const remove = async (id: string) => {
    if (!confirm("Futa mwanafunzi huyu?")) return;
    const { error } = await supabase.from("group_members").delete().eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  // Sort by grand total desc to compute positions
  const ranked = [...members]
    .map((m) => ({ ...m, _total: grandTotal(m) }))
    .sort((a, b) => b._total - a._total);
  const positionOf = (id: string) => ranked.findIndex((r) => r.id === id) + 1;

  const exportExcel = () => {
    if (members.length === 0) return;
    // Editable template. Columns:
    // A=Name of Student, B=Reg No, C=Test 1, D=Test 2, E=Presentation, F=Contribution, G=Total
    const aoa: any[][] = [];
    aoa.push([`${semester?.title || ""} — Group ${group?.group_number}${group?.title ? ` — ${group.title}` : ""}`]);
    aoa.push([]);
    aoa.push(["Name of Student", "Reg No", "Test 1", "Test 2", "Presentation", "Contribution", "Total"]);
    ranked.forEach((m, i) => {
      const r = i + 4; // header on row 3
      aoa.push([
        m.full_name,
        m.reg_no,
        m.test1 ?? 0,
        m.test2 ?? 0,
        m.presentation ?? 0,
        m.contribution ?? 0,
        { f: `SUM(C${r}:F${r})` },
      ]);
    });
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [
      { wch: 28 }, { wch: 22 }, { wch: 10 }, { wch: 10 }, { wch: 14 }, { wch: 14 }, { wch: 12 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Group ${group?.group_number}`);
    XLSX.writeFile(wb, `${(semester?.title || "Semester").replace(/\s+/g, "_")}_Group${group?.group_number}_Coursework.xlsx`);
  };

  // Import Excel: smart-merge by Reg No.
  // Accepts any subset of columns: Name of Student / Full Name / Name, Reg No / Reg, Test 1, Test 2, Presentation, Contribution.
  // - If Reg No matches existing member: update only the columns that are present.
  // - Otherwise: insert new member (Name + Reg No are required for new rows).
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const importExcel = async (file: File) => {
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      if (!ws) return toast.error("Empty workbook");
      const aoa: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false }) as any[][];
      // Find header row: the row that contains a recognizable column.
      const norm = (s: any) => String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
      const headerKeys: Record<string, string> = {
        "name of student": "full_name", "full name": "full_name", "name": "full_name", "jina": "full_name", "jina kamili": "full_name",
        "reg no": "reg_no", "reg": "reg_no", "registration number": "reg_no", "registration": "reg_no",
        "test 1": "test1", "test1": "test1",
        "test 2": "test2", "test2": "test2",
        "presentation": "presentation", "present.": "presentation",
        "contribution": "contribution", "contrib.": "contribution",
      };
      let headerIdx = -1;
      let mapping: Record<number, string> = {};
      for (let i = 0; i < aoa.length; i++) {
        const row = aoa[i] || [];
        const m: Record<number, string> = {};
        row.forEach((cell, idx) => {
          const k = headerKeys[norm(cell)];
          if (k) m[idx] = k;
        });
        if (Object.values(m).includes("reg_no")) { headerIdx = i; mapping = m; break; }
      }
      if (headerIdx < 0) return toast.error("Could not find a 'Reg No' column in the Excel file.");

      // Build maps of existing members by reg_no
      const { data: existing } = await supabase.from("group_members").select("*").eq("group_id", groupId);
      const byReg: Record<string, any> = {};
      (existing || []).forEach((m: any) => { byReg[String(m.reg_no).toUpperCase().trim()] = m; });

      let inserted = 0, updated = 0, skipped = 0;
      for (let i = headerIdx + 1; i < aoa.length; i++) {
        const row = aoa[i] || [];
        if (row.every((c) => c === undefined || c === null || c === "")) continue;
        const rowObj: any = {};
        Object.entries(mapping).forEach(([idxStr, key]) => {
          const v = row[Number(idxStr)];
          if (v === undefined || v === null || v === "") return;
          if (["test1", "test2", "presentation", "contribution"].includes(key)) {
            const n = Number(v);
            if (!Number.isNaN(n)) rowObj[key] = n;
          } else {
            rowObj[key] = String(v).trim();
          }
        });
        const reg = String(rowObj.reg_no || "").toUpperCase().trim();
        if (!reg) { skipped++; continue; }
        rowObj.reg_no = reg;
        if (byReg[reg]) {
          // Update only provided fields (don't wipe full_name if not given)
          const patch: any = {};
          ["full_name", "test1", "test2", "presentation", "contribution"].forEach((k) => {
            if (rowObj[k] !== undefined) patch[k] = rowObj[k];
          });
          if (Object.keys(patch).length === 0) { skipped++; continue; }
          const { error } = await supabase.from("group_members").update(patch).eq("id", byReg[reg].id);
          if (error) { skipped++; continue; }
          updated++;
        } else {
          if (!rowObj.full_name) {
            // No name: still insert with reg_no as placeholder name so admin can edit later.
            rowObj.full_name = reg;
          }
          if (!REG_NO_REGEX.test(reg)) {
            // Allow but warn — store anyway since admin may use legacy formats in upload.
          }
          const { error } = await supabase.from("group_members").insert({
            group_id: groupId,
            full_name: rowObj.full_name,
            reg_no: reg,
            test1: rowObj.test1 ?? null,
            test2: rowObj.test2 ?? null,
            presentation: rowObj.presentation ?? null,
            contribution: rowObj.contribution ?? null,
          });
          if (error) { skipped++; continue; }
          inserted++;
        }
      }
      toast.success(`Import complete: ${inserted} added, ${updated} updated${skipped ? `, ${skipped} skipped` : ""}.`);
      load();
    } catch (e: any) {
      toast.error(e.message || "Failed to import Excel");
    }
  };

  const exportPDF = () => {
    if (members.length === 0) return;
    const doc = new jsPDF({ orientation: "landscape" });
    doc.setFontSize(14); doc.setFont("helvetica", "bold");
    doc.text("Islamic Study Test Online — Coursework & Examination Report", 14, 14);
    doc.setFontSize(10); doc.setFont("helvetica", "normal");
    doc.text(`Semester: ${semester?.title || ""}`, 14, 21);
    doc.text(`Group ${group?.group_number}${group?.title ? ` — ${group.title}` : ""}`, 14, 27);
    doc.text(`Date: ${new Date().toLocaleString()}`, 14, 33);

    // PDF: Reg No, Jina, Sex, Course, Test 1, Test 2, Presentation, Pre.Doc, Contribution, Attendance, Quiz, Total Coursework (40), University Exam (60), Total Marks (100), Position, Remarks
    autoTable(doc, {
      startY: 38,
      head: [[
        "Reg No", "Jina", "Sex", "Course", "Test 1", "Test 2", "Present.", "Pre.Doc",
        "Contrib.", "Attend.", "Quiz", "CW (40)", "Univ (60)", "Total (100)", "Pos", "Remarks"
      ]],
      body: ranked.map((m, i) => [
        m.reg_no,
        m.full_name,
        m.gender || "—",
        m.course || "—",
        m.test1 ?? "—",
        m.test2 ?? "—",
        m.presentation ?? "—",
        m.presentation_doc ?? "—",
        m.contribution ?? "—",
        m.attendance ?? "—",
        m.quiz ?? "—",
        courseworkTotal(m).toFixed(1),
        uniExam(m),
        grandTotal(m).toFixed(1),
        i + 1,
        remarkOf(m),
      ]),
      styles: { fontSize: 7, cellPadding: 1.3 },
      headStyles: { fillColor: [15, 35, 70], textColor: 255, fontStyle: "bold" },
      alternateRowStyles: { fillColor: [245, 247, 250] },
    });

    doc.save(`${(semester?.title || "Semester").replace(/\s+/g, "_")}_Group${group?.group_number}_Report.pdf`);
  };

  if (!group) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to={`/admin/semesters/${group.semester_id}/groups`} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Magroup
        </Link>
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-extrabold">Group {group.group_number}{group.title ? ` — ${group.title}` : ""}</h1>
            <p className="text-sm text-muted-foreground">{semester?.title}</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) importExcel(f);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }}
            />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-1" /> Import Excel
            </Button>
            <Button variant="outline" onClick={exportExcel} disabled={members.length === 0}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Excel
            </Button>
            <Button variant="outline" onClick={exportPDF} disabled={members.length === 0}>
              <FileDown className="h-4 w-4 mr-1" /> PDF
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground -mt-3 mb-4">
          Tip: You can upload an Excel with any subset of columns (Name, Reg No, Test 1, Test 2, Presentation, Contribution). Rows with a matching Reg No will be updated; new ones will be added.
        </p>

        <Card className="p-6 mb-6 shadow-card">
          <h2 className="font-bold mb-4">Ongeza Mwanafunzi</h2>
          <form onSubmit={addMember} className="grid md:grid-cols-3 lg:grid-cols-6 gap-3 items-end">
            <div className="lg:col-span-2">
              <Label>Jina kamili</Label>
              <Input value={fullName} onChange={(e) => setFullName(e.target.value)} required />
            </div>
            <div>
              <Label>Reg No</Label>
              <Input value={regNo} onChange={(e) => setRegNo(e.target.value.toUpperCase())}
                placeholder="2021-04-93392" required className="font-mono-num" />
            </div>
            <div>
              <Label>Sex</Label>
              <select value={gender} onChange={(e) => setGender(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm">
                <option value="">—</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
            <div>
              <Label>Course</Label>
              <Input value={course} onChange={(e) => setCourse(e.target.value)} placeholder="BSc IS" />
            </div>
            <Button type="submit"><Plus className="h-4 w-4 mr-1" /> Ongeza</Button>
          </form>
        </Card>

        {members.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Hakuna mwanafunzi bado.
          </Card>
        ) : (
          <Card className="overflow-hidden shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-2 py-3 text-left">Reg No</th>
                    <th className="px-2 py-3 text-left">Jina</th>
                    <th className="px-2 py-3 text-center">Sex</th>
                    <th className="px-2 py-3 text-right">Test 1</th>
                    <th className="px-2 py-3 text-right">Test 2</th>
                    <th className="px-2 py-3 text-right">Present.</th>
                    <th className="px-2 py-3 text-right">Pre.Doc</th>
                    <th className="px-2 py-3 text-right">Contrib.</th>
                    <th className="px-2 py-3 text-right">Attend.</th>
                    <th className="px-2 py-3 text-right">Quiz</th>
                    <th className="px-2 py-3 text-right">CW/40</th>
                    <th className="px-2 py-3 text-right">Univ/60</th>
                    <th className="px-2 py-3 text-right">Total</th>
                    <th className="px-2 py-3 text-center">Pos</th>
                    <th className="px-2 py-3 text-center">Remarks</th>
                    <th className="px-2 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {members.map((m) => {
                    const cw = courseworkTotal(m);
                    const ue = uniExam(m);
                    const tot = cw + ue;
                    const remark = remarkOf(m);
                    const inputCls = "h-8 w-16 ml-auto font-mono-num text-right text-xs";
                    return (
                      <tr key={m.id} className="hover:bg-muted/30">
                        <td className="px-2 py-2 font-mono-num">{m.reg_no}</td>
                        <td className="px-2 py-2 font-semibold">{m.full_name}</td>
                        <td className="px-2 py-2 text-center text-muted-foreground">{m.gender || "—"}</td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.test1 ?? ""} onBlur={(e) => updateField(m.id, "test1", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.test2 ?? ""} onBlur={(e) => updateField(m.id, "test2", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.presentation ?? ""} onBlur={(e) => updateField(m.id, "presentation", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.presentation_doc ?? ""} onBlur={(e) => updateField(m.id, "presentation_doc", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.contribution ?? ""} onBlur={(e) => updateField(m.id, "contribution", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.attendance ?? ""} onBlur={(e) => updateField(m.id, "attendance", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.quiz ?? ""} onBlur={(e) => updateField(m.id, "quiz", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2 text-right font-mono-num font-bold">{cw.toFixed(1)}</td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" max={60} defaultValue={m.university_exam ?? ""} onBlur={(e) => updateField(m.id, "university_exam", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2 text-right font-mono-num font-extrabold">{tot.toFixed(1)}</td>
                        <td className="px-2 py-2 text-center font-mono-num">{positionOf(m.id)}</td>
                        <td className="px-2 py-2 text-center">
                          <span className={`text-[10px] uppercase tracking-widest px-2 py-1 rounded-full font-semibold ${remark === "DONE" ? "bg-accent/10 text-accent" : "bg-warning/10 text-warning"}`}>
                            {remark}
                          </span>
                        </td>
                        <td className="px-2 py-2 text-right">
                          <Button size="sm" variant="ghost" onClick={() => remove(m.id)} className="text-destructive hover:text-destructive">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="px-4 py-3 text-[11px] text-muted-foreground bg-muted/30 border-t">
              Coursework = Presentation + Pre.Doc + (Test1/20×15) + (Test2/20×15) + Attendance + Contribution + Quiz (jumla 40). University Exam max 60. Total = 100. Remarks: <b>DONE</b> kama vyote vimejazwa, vinginevyo <b>INCOMPLETE</b>.
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminGroupMembers;
