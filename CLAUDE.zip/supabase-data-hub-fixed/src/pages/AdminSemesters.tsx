import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, BookOpen, Users } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

interface Semester { id: string; title: string; description: string | null; is_active: boolean; }

const AdminSemesters = () => {
  const navigate = useNavigate();
  const [list, setList] = useState<Semester[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [navigate]);

  const load = async () => {
    const { data } = await supabase.from("semesters").select("*").order("created_at", { ascending: false });
    setList((data as any) || []);
  };

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const { error } = await supabase.from("semesters").insert({ title: title.trim(), description: description.trim() || null });
    if (error) return toast.error(error.message);
    toast.success("Semina imetengenezwa");
    setTitle(""); setDescription(""); setShowForm(false);
    load();
  };

  const remove = async (id: string) => {
    if (!confirm("Futa semina hii? Magroup na wanafunzi wote watafutwa.")) return;
    const { error } = await supabase.from("semesters").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Imefutwa");
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-extrabold">Semina (Semesters)</h1>
            <p className="text-sm text-muted-foreground">Tengeneza semina, kisha ongeza magroup na wanafunzi.</p>
          </div>
          <Button onClick={() => setShowForm(!showForm)}><Plus className="h-4 w-4 mr-1" /> Semina Mpya</Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-6 shadow-card">
            <form onSubmit={create} className="space-y-3">
              <div>
                <Label>Kichwa cha Semina (mfano: IS 200)</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="IS 200" required />
              </div>
              <div>
                <Label>Maelezo (hiari)</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
              </div>
              <div className="flex gap-2">
                <Button type="submit">Tengeneza</Button>
                <Button type="button" variant="ghost" onClick={() => setShowForm(false)}>Funga</Button>
              </div>
            </form>
          </Card>
        )}

        {list.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <BookOpen className="h-12 w-12 mx-auto mb-3 opacity-40" />
            Hakuna semina bado.
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {list.map((s) => (
              <Card key={s.id} className="p-5 shadow-card">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <h3 className="font-bold text-lg">{s.title}</h3>
                    {s.description && <p className="text-sm text-muted-foreground line-clamp-2">{s.description}</p>}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/admin/semesters/${s.id}/groups`}><Users className="h-3.5 w-3.5 mr-1" /> Magroup</Link>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(s.id)} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminSemesters;
