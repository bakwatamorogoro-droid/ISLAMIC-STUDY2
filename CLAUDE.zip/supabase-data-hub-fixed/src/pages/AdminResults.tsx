// @ts-nocheck
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Users, FileSpreadsheet, FileDown, Eye, Globe, Upload, Trash2, RefreshCw, FileText, Search, Lock, ShieldCheck, Save } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { exportResultsToPDF, exportRowsToCSV, ResultRow } from "@/lib/exportResults";
import { toast } from "sonner";
import * as XLSX from "xlsx";

type MarkField = "test1" | "test2" | "presentation" | "contribution";
const num = (v: any): number => (v === null || v === undefined || v === "" ? 0 : Number(v) || 0);
const totalOf = (m: any) => num(m.test1) + num(m.test2) + num(m.presentation) + num(m.contribution);

const AdminResults = () => {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState<any>(null);
  const [rows, setRows] = useState<any[]>([]);
  const [marks, setMarks] = useState<any[]>([]);
  const [allStudents, setAllStudents] = useState<any[]>([]);
  const [publishing, setPublishing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [assessment, setAssessment] = useState<MarkField | "">("");
  const [marksSearch, setMarksSearch] = useState("");

  // Management (password-protected): edit a student's MARKS for this exam
  const MGMT_PASSWORD = "2025/2026";
  const [mgmtAuth, setMgmtAuth] = useState(false);
  const [mgmtPwd, setMgmtPwd] = useState("");
  const [mgmtSearch, setMgmtSearch] = useState("");
  const [mgmtMatches, setMgmtMatches] = useState<any[]>([]);
  const [mgmtLoading, setMgmtLoading] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [editMarks, setEditMarks] = useState<{ test1: string; test2: string; presentation: string; contribution: string; score: string }>({ test1: "", test2: "", presentation: "", contribution: "", score: "" });

  const tryUnlockMgmt = () => {
    if (mgmtPwd.trim() === MGMT_PASSWORD) {
      setMgmtAuth(true);
      toast.success("Management imefunguliwa.");
    } else {
      toast.error("Password si sahihi.");
    }
  };

  const runMgmtSearch = async () => {
    const q = mgmtSearch.trim();
    if (!q) return toast.error("Andika Reg No au jina.");
    setMgmtLoading(true);
    try {
      const { data } = await supabase
        .from("students")
        .select("id, full_name, exam_number")
        .or(`exam_number.ilike.%${q}%,full_name.ilike.%${q}%`)
        .limit(50);
      const list = (data as any[]) || [];
      const enriched = await Promise.all(list.map(async (s) => {
        const { data: att } = await supabase
          .from("attempts")
          .select("score, total_marks, status")
          .eq("student_id", s.id)
          .eq("exam_id", examId)
          .order("submitted_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        const { data: mk } = await supabase
          .from("exam_marks" as any)
          .select("id, test1, test2, presentation, contribution")
          .eq("exam_id", examId)
          .ilike("reg_no", s.exam_number)
          .maybeSingle();
        return { ...s, attempt: att, mark: mk };
      }));
      setMgmtMatches(enriched);
      if (enriched.length === 0) toast.info("Hakuna taarifa zilizopatikana.");
    } finally {
      setMgmtLoading(false);
    }
  };

  const startEdit = (s: any) => {
    setEditId(s.id);
    setEditMarks({
      test1: s.mark?.test1 ?? "",
      test2: s.mark?.test2 ?? "",
      presentation: s.mark?.presentation ?? "",
      contribution: s.mark?.contribution ?? "",
      score: s.attempt?.score ?? "",
    });
  };

  const saveMarksEdit = async (s: any) => {
    const reg = String(s.exam_number || "").toUpperCase().trim();
    if (!reg) return toast.error("Mwanafunzi hana Reg No.");
    const toNum = (v: string) => (v === "" || v === null || v === undefined ? null : Number(v));
    const payload: any = {
      test1: toNum(editMarks.test1),
      test2: toNum(editMarks.test2),
      presentation: toNum(editMarks.presentation),
      contribution: toNum(editMarks.contribution),
      full_name: s.full_name,
      updated_at: new Date().toISOString(),
    };
    if (s.mark?.id) {
      const { error } = await supabase.from("exam_marks" as any).update(payload).eq("id", s.mark.id);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from("exam_marks" as any).insert({ exam_id: examId, reg_no: reg, ...payload });
      if (error) return toast.error(error.message);
    }
    // Optionally override attempt score
    if (s.attempt?.id && editMarks.score !== "" && editMarks.score !== String(s.attempt.score ?? "")) {
      const sc = Number(editMarks.score);
      if (!Number.isNaN(sc)) {
        await supabase.from("attempts").update({ score: sc }).eq("id", s.attempt.id);
      }
    }
    toast.success("Alama zimerekebishwa. Zitaonekana kwa wote kwenye matokeo.");
    setEditId(null);
    await runMgmtSearch();
    await load();
  };

  useEffect(() => {
    verifyAdmin().then(async (a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [examId]);

  const load = async () => {
    const { data: ex } = await supabase.from("exams").select("*").eq("id", examId).single();
    setExam(ex);
    const fetchAll = async (build: (from: number, to: number) => any) => {
      const pageSize = 1000;
      let from = 0;
      let all: any[] = [];
      // Loop until fewer than pageSize rows are returned
      while (true) {
        const { data, error } = await build(from, from + pageSize - 1);
        if (error) break;
        const chunk = (data as any[]) || [];
        all = all.concat(chunk);
        if (chunk.length < pageSize) break;
        from += pageSize;
      }
      return all;
    };
    const allAttempts = await fetchAll((from, to) =>
      supabase
        .from("attempts")
        .select("id, score, total_marks, status, submitted_at, started_at, violation_reason, needs_grading, students(full_name, exam_number)")
        .eq("exam_id", examId)
        .order("submitted_at", { ascending: false })
        .range(from, to)
    );
    // For attempts where score is null (e.g. still in_progress), compute the
    // live score from the `answers` table so admins can see real marks earned.
    const needLive = allAttempts.filter((a: any) => a.score == null).map((a: any) => a.id);
    if (needLive.length) {
      const liveMap: Record<string, number> = {};
      const chunkSize = 200;
      for (let i = 0; i < needLive.length; i += chunkSize) {
        const ids = needLive.slice(i, i + chunkSize);
        const { data: ans } = await supabase
          .from("answers")
          .select("attempt_id, is_correct, awarded_marks")
          .in("attempt_id", ids);
        (ans || []).forEach((a: any) => {
          const pts = a.awarded_marks != null ? Number(a.awarded_marks) : (a.is_correct ? 1 : 0);
          liveMap[a.attempt_id] = (liveMap[a.attempt_id] || 0) + (Number.isFinite(pts) ? pts : 0);
        });
      }
      allAttempts.forEach((a: any) => {
        if (a.score == null) a.score = liveMap[a.id] || 0;
      });
    }
    setRows(allAttempts);
    const allMarks = await fetchAll((from, to) =>
      supabase
        .from("exam_marks" as any)
        .select("*")
        .eq("exam_id", examId)
        .order("full_name")
        .range(from, to)
    );
    setMarks(allMarks);
    const students = await fetchAll((from, to) =>
      supabase
        .from("students")
        .select("id, full_name, exam_number")
        .order("full_name")
        .range(from, to)
    );
    setAllStudents(students);
  };

  const togglePublish = async (val: boolean) => {
    setPublishing(true);
    const { error } = await supabase.from("exams").update({ results_published: val }).eq("id", examId);
    setPublishing(false);
    if (error) return toast.error(error.message);
    toast.success(val ? "Results published! Students can now view them." : "Results hidden.");
    setExam({ ...exam, results_published: val });
  };

  // Merge all registered students with their attempts so every student appears,
  // even those who did not take the exam (status: "hakufanya").
  const toResultRows = (): ResultRow[] => {
    const byReg: Record<string, any> = {};
    rows.forEach((r) => {
      const reg = String(r.students?.exam_number || "").toUpperCase().trim();
      if (reg) byReg[reg] = r;
    });
    return allStudents.map((s) => {
      const reg = String(s.exam_number || "").toUpperCase().trim();
      const r = byReg[reg];
      if (r) {
        return {
          full_name: r.students?.full_name || s.full_name || "",
          exam_number: r.students?.exam_number || s.exam_number || "",
          score: r.score,
          total_marks: r.total_marks,
          status: r.status,
          submitted_at: r.submitted_at,
          violation_reason: r.violation_reason,
        };
      }
      return {
        full_name: s.full_name || "",
        exam_number: s.exam_number || "",
        score: null,
        total_marks: null,
        status: "hakufanya",
        submitted_at: null,
        violation_reason: null,
      };
    });
  };

  // Seed exam_marks from attempts. If an assessment column is chosen, also populate
  // that column with the student's raw score (e.g. 1, 0, 5) — not "score/total".
  const seedFromAttempts = async () => {
    if (rows.length === 0) return toast.info("No attempts yet.");
    const existingByReg: Record<string, any> = {};
    marks.forEach((m) => { existingByReg[String(m.reg_no).toUpperCase().trim()] = m; });

    let inserted = 0, updated = 0;
    for (const r of rows) {
      const reg = String(r.students?.exam_number || "").toUpperCase().trim();
      if (!reg) continue;
      const name = r.students?.full_name || reg;
      const score = r.score != null ? Number(r.score) : null;
      const existing = existingByReg[reg];
      if (existing) {
        if (assessment && score != null) {
          const { error } = await supabase.from("exam_marks" as any)
            .update({ [assessment]: score, full_name: name }).eq("id", existing.id);
          if (!error) updated++;
        }
      } else {
        const payload: any = { exam_id: examId, full_name: name, reg_no: reg };
        if (assessment && score != null) payload[assessment] = score;
        const { error } = await supabase.from("exam_marks" as any).insert(payload);
        if (!error) inserted++;
      }
    }
    toast.success(
      assessment
        ? `Pulled ${inserted + updated} student(s) into "${assessment}" column.`
        : `Pulled ${inserted} student(s). Tip: chagua assessment kabla ili alama ziingie automatically.`,
    );
    load();
  };

  const updateMark = async (id: string, field: MarkField, value: string) => {
    const v = value === "" ? null : parseFloat(value);
    const { error } = await supabase.from("exam_marks" as any).update({ [field]: v }).eq("id", id);
    if (error) return toast.error(error.message);
    setMarks(marks.map((m) => m.id === id ? { ...m, [field]: v } : m));
  };

  const removeMark = async (id: string) => {
    if (!confirm("Remove this row?")) return;
    const { error } = await supabase.from("exam_marks" as any).delete().eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  // Export Excel template: Name of Student, Reg No, Test 1, Test 2, Presentation, Contribution, Total
  const exportMarksExcel = () => {
    const aoa: any[][] = [];
    aoa.push([`${exam?.title || "Exam"} — Marks`]);
    aoa.push([]);
    aoa.push(["Name of Student", "Reg No", "Test 1", "Test 2", "Presentation", "Contribution", "Total"]);
    // Always include EVERY registered student. Merge with any saved marks.
    const marksByReg: Record<string, any> = {};
    marks.forEach((m) => { marksByReg[String(m.reg_no).toUpperCase().trim()] = m; });
    const data = allStudents.map((s) => {
      const reg = String(s.exam_number || "").toUpperCase().trim();
      const m = marksByReg[reg];
      return {
        full_name: (m?.full_name) || s.full_name || "",
        reg_no: s.exam_number || "",
        test1: m?.test1 ?? null,
        test2: m?.test2 ?? null,
        presentation: m?.presentation ?? null,
        contribution: m?.contribution ?? null,
      };
    });
    data.forEach((m: any, i: number) => {
      const r = i + 4;
      aoa.push([
        m.full_name,
        m.reg_no,
        m.test1 ?? 0,
        m.test2 ?? 0,
        m.presentation ?? 0,
        m.contribution ?? 0,
        { f: `SUM(C${r}:F${r})` },
      ]);
    });
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [
      { wch: 28 }, { wch: 22 }, { wch: 10 }, { wch: 10 }, { wch: 14 }, { wch: 14 }, { wch: 12 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Marks");
    XLSX.writeFile(wb, `${(exam?.title || "Exam").replace(/\s+/g, "_")}_Marks.xlsx`);
  };

  const exportMarksCSV = () => {
    const marksByReg: Record<string, any> = {};
    marks.forEach((m) => { marksByReg[String(m.reg_no).toUpperCase().trim()] = m; });
    const data = allStudents.map((s) => {
      const reg = String(s.exam_number || "").toUpperCase().trim();
      const m = marksByReg[reg];
      return {
        full_name: (m?.full_name) || s.full_name || "",
        reg_no: s.exam_number || "",
        test1: m?.test1 ?? null,
        test2: m?.test2 ?? null,
        presentation: m?.presentation ?? null,
        contribution: m?.contribution ?? null,
      };
    });
    if (data.length === 0) return toast.info("No marks to export.");
    const body = data.map((m: any) => [
      m.full_name,
      m.reg_no,
      m.test1 ?? 0,
      m.test2 ?? 0,
      m.presentation ?? 0,
      m.contribution ?? 0,
      totalOf(m).toFixed(1),
    ]);
    exportRowsToCSV(
      `${(exam?.title || "Exam").replace(/\s+/g, "_")}_Marks.csv`,
      ["Name of Student", "Reg No", "Test 1", "Test 2", "Presentation", "Contribution", "Total"],
      body,
    );
  };

  // Export marks as a Word (.doc) file — opens directly in Microsoft Word.
  const exportMarksWord = () => {
    const marksByReg: Record<string, any> = {};
    marks.forEach((m) => { marksByReg[String(m.reg_no).toUpperCase().trim()] = m; });
    const data = allStudents.map((s) => {
      const reg = String(s.exam_number || "").toUpperCase().trim();
      const m = marksByReg[reg];
      return {
        full_name: (m?.full_name) || s.full_name || "",
        reg_no: s.exam_number || "",
        test1: m?.test1 ?? 0,
        test2: m?.test2 ?? 0,
        presentation: m?.presentation ?? 0,
        contribution: m?.contribution ?? 0,
        total: totalOf(m || {}).toFixed(1),
      };
    });
    const title = exam?.title || "Exam";
    const rowsHtml = data.map((m, i) => `
      <tr>
        <td>${i + 1}</td>
        <td>${m.full_name}</td>
        <td>${m.reg_no}</td>
        <td style="text-align:right">${m.test1}</td>
        <td style="text-align:right">${m.test2}</td>
        <td style="text-align:right">${m.presentation}</td>
        <td style="text-align:right">${m.contribution}</td>
        <td style="text-align:right"><b>${m.total}</b></td>
      </tr>`).join("");
    const html = `<!DOCTYPE html><html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head><meta charset='utf-8'><title>${title}</title>
<style>body{font-family:Arial,sans-serif;font-size:11pt}h1{font-size:16pt}h2{font-size:12pt;color:#555}table{border-collapse:collapse;width:100%}th,td{border:1px solid #888;padding:4px 6px}th{background:#0F2346;color:#fff;text-align:left}</style>
</head><body>
<h1>ISLAMIC STUDIES MUM</h1>
<h2>${title} — Coursework Marks</h2>
<p>Tarehe: ${new Date().toLocaleString()} • Jumla ya Wanafunzi: ${data.length}</p>
<table><thead><tr><th>#</th><th>Name of Student</th><th>Reg No</th><th>Test 1</th><th>Test 2</th><th>Presentation</th><th>Contribution</th><th>Total</th></tr></thead>
<tbody>${rowsHtml}</tbody></table>
</body></html>`;
    const blob = new Blob(["\ufeff", html], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${title.replace(/\s+/g, "_")}_Marks.doc`; a.click();
    URL.revokeObjectURL(url);
  };

  const exportEssayAllWord = async () => {
    const data = await fetchEssayRows();
    if (!data.length) return toast.info("Hakuna majibu ya essay.");
    const rowsHtml = data.map((r) => `
      <tr><td>${r.name}</td><td>${r.reg}</td><td>${r.type}</td>
      <td>${(r.question || "").replace(/</g, "&lt;")}</td>
      <td>${(r.correct || "").replace(/</g, "&lt;")}</td>
      <td>${(r.student || "").replace(/</g, "&lt;")}</td>
      <td style="text-align:right">${r.awarded}</td><td style="text-align:right">${r.total}</td></tr>`).join("");
    const title = exam?.title || "Exam";
    const html = `<!DOCTYPE html><html><head><meta charset='utf-8'><title>${title} Essays</title>
<style>body{font-family:Arial;font-size:10pt}table{border-collapse:collapse;width:100%}th,td{border:1px solid #888;padding:4px;vertical-align:top}th{background:#0F2346;color:#fff}</style></head>
<body><h1>ISLAMIC STUDIES MUM — ${title} (Essays)</h1>
<table><thead><tr><th>Jina</th><th>Reg No</th><th>Aina</th><th>Swali</th><th>Jibu Sahihi</th><th>Jibu la Mwanafunzi</th><th>Alama</th><th>Jumla</th></tr></thead>
<tbody>${rowsHtml}</tbody></table></body></html>`;
    const blob = new Blob(["\ufeff", html], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${title.replace(/\s+/g, "_")}_Essays.doc`; a.click();
    URL.revokeObjectURL(url);
  };

  const fetchEssayRows = async () => {
    const { data: qs } = await supabase.from("questions").select("id, question_text, question_type, correct_answer, marks").eq("exam_id", examId);
    const essays = ((qs as any) || []).filter((q: any) => q.question_type === "short_answer" || q.question_type === "long_answer");
    if (essays.length === 0 || rows.length === 0) return [];
    const attemptIds = rows.map((r) => r.id);
    // Chunk attemptIds (URL length) and paginate (1000-row default cap)
    const ans: any[] = [];
    const idChunks: string[][] = [];
    for (let i = 0; i < attemptIds.length; i += 200) idChunks.push(attemptIds.slice(i, i + 200));
    for (const ids of idChunks) {
      let from = 0;
      const pageSize = 1000;
      while (true) {
        const { data, error } = await supabase
          .from("answers")
          .select("*")
          .in("attempt_id", ids)
          .range(from, from + pageSize - 1);
        if (error) break;
        const chunk = (data as any[]) || [];
        ans.push(...chunk);
        if (chunk.length < pageSize) break;
        from += pageSize;
      }
    }
    const out: any[] = [];
    rows.forEach((r) => {
      essays.forEach((q: any) => {
        const a = ans.find((x: any) => x.attempt_id === r.id && x.question_id === q.id);
        const awarded = a?.awarded_marks != null ? Number(a.awarded_marks) : (a?.is_correct ? q.marks : 0);
        out.push({
          name: r.students?.full_name || "", reg: r.students?.exam_number || "",
          type: q.question_type === "short_answer" ? "Jibu Fupi" : "Insha",
          question: q.question_text, correct: q.correct_answer || "",
          student: a?.answer_text || "", awarded, total: q.marks,
        });
      });
    });
    return out;
  };
  const exportEssayAll = async () => {
    const data = await fetchEssayRows();
    if (!data.length) return toast.info("Hakuna majibu ya essay.");
    exportRowsToCSV(`${(exam?.title || "Exam").replace(/\s+/g, "_")}_Essays.csv`,
      ["Jina", "Reg No", "Aina", "Swali", "Jibu Sahihi", "Jibu la Mwanafunzi", "Alama", "Jumla"],
      data.map((r) => [r.name, r.reg, r.type, r.question, r.correct, r.student, r.awarded, r.total]));
  };
  const exportEssayAllExcel = async () => {
    const data = await fetchEssayRows();
    if (!data.length) return toast.info("Hakuna majibu ya essay.");
    const aoa: any[][] = [[`${exam?.title} — Essays`], [],
      ["Jina", "Reg No", "Aina", "Swali", "Jibu Sahihi", "Jibu la Mwanafunzi", "Alama", "Jumla"]];
    data.forEach((r) => aoa.push([r.name, r.reg, r.type, r.question, r.correct, r.student, r.awarded, r.total]));
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = [{ wch: 22 }, { wch: 16 }, { wch: 10 }, { wch: 35 }, { wch: 25 }, { wch: 35 }, { wch: 8 }, { wch: 8 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Essays");
    XLSX.writeFile(wb, `${(exam?.title || "Exam").replace(/\s+/g, "_")}_Essays.xlsx`);
  };

  // Import Excel: smart-merge by Reg No (case-insensitive). Accepts any subset of columns.
  const importExcel = async (file: File) => {
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const ws = wb.Sheets[wb.SheetNames[0]];
      if (!ws) return toast.error("Empty workbook");
      const aoa: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, blankrows: false }) as any[][];
      const norm = (s: any) => String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
      const headerKeys: Record<string, string> = {
        "name of student": "full_name", "full name": "full_name", "name": "full_name", "jina": "full_name", "jina kamili": "full_name",
        "reg no": "reg_no", "reg": "reg_no", "registration number": "reg_no", "registration": "reg_no", "exam number": "reg_no",
        "test 1": "test1", "test1": "test1",
        "test 2": "test2", "test2": "test2",
        "presentation": "presentation",
        "contribution": "contribution",
      };
      let headerIdx = -1;
      let mapping: Record<number, string> = {};
      for (let i = 0; i < aoa.length; i++) {
        const row = aoa[i] || [];
        const m: Record<number, string> = {};
        row.forEach((cell, idx) => {
          const k = headerKeys[norm(cell)];
          if (k) m[idx] = k;
        });
        if (Object.values(m).includes("reg_no")) { headerIdx = i; mapping = m; break; }
      }
      if (headerIdx < 0) return toast.error("Could not find a 'Reg No' column in the Excel file.");

      const { data: existing } = await supabase.from("exam_marks" as any).select("*").eq("exam_id", examId);
      const byReg: Record<string, any> = {};
      ((existing as any) || []).forEach((m: any) => { byReg[String(m.reg_no).toUpperCase().trim()] = m; });

      let inserted = 0, updated = 0, skipped = 0;
      for (let i = headerIdx + 1; i < aoa.length; i++) {
        const row = aoa[i] || [];
        if (row.every((c) => c === undefined || c === null || c === "")) continue;
        const rowObj: any = {};
        Object.entries(mapping).forEach(([idxStr, key]) => {
          const v = row[Number(idxStr)];
          if (v === undefined || v === null || v === "") return;
          if (["test1", "test2", "presentation", "contribution"].includes(key)) {
            const n = Number(v);
            if (!Number.isNaN(n)) rowObj[key] = n;
          } else {
            rowObj[key] = String(v).trim();
          }
        });
        const reg = String(rowObj.reg_no || "").toUpperCase().trim();
        if (!reg) { skipped++; continue; }
        rowObj.reg_no = reg;
        if (byReg[reg]) {
          const patch: any = { updated_at: new Date().toISOString() };
          ["full_name", "test1", "test2", "presentation", "contribution"].forEach((k) => {
            if (rowObj[k] !== undefined) patch[k] = rowObj[k];
          });
          if (Object.keys(patch).length === 1) { skipped++; continue; }
          const { error } = await supabase.from("exam_marks" as any).update(patch).eq("id", byReg[reg].id);
          if (error) { skipped++; continue; }
          updated++;
        } else {
          const { error } = await supabase.from("exam_marks" as any).insert({
            exam_id: examId,
            full_name: rowObj.full_name || reg,
            reg_no: reg,
            test1: rowObj.test1 ?? null,
            test2: rowObj.test2 ?? null,
            presentation: rowObj.presentation ?? null,
            contribution: rowObj.contribution ?? null,
          });
          if (error) { skipped++; continue; }
          inserted++;
        }
      }
      toast.success(`Import complete: ${inserted} added, ${updated} updated${skipped ? `, ${skipped} skipped` : ""}.`);
      load();
    } catch (e: any) {
      toast.error(e.message || "Failed to import Excel");
    }
  };

  if (!exam) return null;

  const statusBadge = (s: string) => {
    const map: Record<string, string> = {
      submitted: "bg-accent/10 text-accent",
      auto_submitted: "bg-warning/10 text-warning",
      terminated: "bg-destructive/10 text-destructive",
      in_progress: "bg-muted text-muted-foreground",
    };
    return <span className={`text-[10px] uppercase tracking-widest px-2 py-1 rounded-full font-semibold ${map[s] || ""}`}>{s.replace("_", " ")}</span>;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Exams
        </Link>
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <h1 className="text-2xl font-extrabold mb-1">Results: {exam.title}</h1>
            <p className="text-sm text-muted-foreground">
              {(() => {
                const took = rows.filter((r) => r.status !== "in_progress").length;
                const submitted = rows.filter((r) => r.status === "submitted" || r.status === "auto_submitted").length;
                const cheated = rows.filter((r) => r.status === "terminated").length;
                const inProg = rows.filter((r) => r.status === "in_progress").length;
                return `Walifanya: ${took} • Walitumiza: ${submitted} • Walidanganya: ${cheated} • Bado: ${inProg} • Wasajili: ${allStudents.length}`;
              })()}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) importExcel(f);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }}
            />
            <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-1" /> Import Excel
            </Button>
            <Button variant="outline" size="sm" onClick={exportMarksExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Excel
            </Button>
            <Button variant="outline" size="sm" onClick={exportMarksCSV}>
              <FileDown className="h-4 w-4 mr-1" /> CSV
            </Button>
            <Button variant="outline" size="sm" onClick={exportMarksWord}>
              <FileText className="h-4 w-4 mr-1" /> Word
            </Button>
            <Button variant="outline" size="sm" disabled={rows.length === 0} onClick={() => exportResultsToPDF(exam.title, toResultRows())}>
              <FileDown className="h-4 w-4 mr-1" /> PDF
            </Button>
            <Button variant="outline" size="sm" disabled={rows.length === 0} onClick={exportEssayAll}>
              <FileDown className="h-4 w-4 mr-1" /> Essay CSV
            </Button>
            <Button variant="outline" size="sm" disabled={rows.length === 0} onClick={exportEssayAllExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-1" /> Essay Excel
            </Button>
            <Button variant="outline" size="sm" disabled={rows.length === 0} onClick={exportEssayAllWord}>
              <FileText className="h-4 w-4 mr-1" /> Essay Word
            </Button>
          </div>
        </div>

        <Card className="p-4 mb-6 shadow-card flex items-center justify-between gap-4 flex-wrap bg-gradient-card">
          <div className="flex items-center gap-3">
            <div className={`h-10 w-10 rounded-xl grid place-items-center ${exam.results_published ? "bg-accent/15 text-accent" : "bg-muted text-muted-foreground"}`}>
              <Globe className="h-5 w-5" />
            </div>
            <div>
              <div className="font-bold">Publish Results</div>
              <div className="text-xs text-muted-foreground">
                {exam.results_published
                  ? "Students can view their results using their registration number."
                  : "Results are hidden from students."}
              </div>
            </div>
          </div>
          <Switch checked={exam.results_published} onCheckedChange={togglePublish} disabled={publishing} />
        </Card>

        {/* Coursework-style marks table */}
        <Card className="p-4 mb-6 shadow-card">
          <div className="flex items-start justify-between gap-3 flex-wrap mb-3">
            <div className="min-w-0 flex-1">
              <h2 className="font-bold flex items-center gap-2">
                <FileSpreadsheet className="h-4 w-4 text-accent" /> Coursework Marks
              </h2>
              <p className="text-xs text-muted-foreground mt-1">
                Columns: Name of Student, Reg No, Test 1, Test 2, Presentation, Contribution, Total. Use Import to upload an Excel — even a single column is enough.
              </p>
              <div className="mt-2 flex items-center gap-2 flex-wrap">
                <label className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold">Assessment Type:</label>
                <select
                  value={assessment}
                  onChange={(e) => setAssessment(e.target.value as MarkField | "")}
                  className="h-8 rounded-md border border-input bg-background px-2 text-xs font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="">— choose —</option>
                  <option value="test1">Test 1</option>
                  <option value="test2">Test 2</option>
                  <option value="presentation">Presentation</option>
                  <option value="contribution">Contribution</option>
                </select>
                {assessment && (
                  <span className="text-[10px] text-accent font-bold">
                    Pull Students itaweka alama kwenye "{assessment}" automatically.
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" onClick={seedFromAttempts} disabled={rows.length === 0}>
                <RefreshCw className="h-4 w-4 mr-1" /> Pull Students from Attempts
              </Button>
              <Button size="sm" onClick={exportMarksExcel} className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <FileSpreadsheet className="h-4 w-4 mr-1" /> Download Excel
              </Button>
              <Button size="sm" variant="outline" onClick={exportMarksCSV}>
                <FileDown className="h-4 w-4 mr-1" /> Download CSV
              </Button>
              <Button size="sm" variant="outline" onClick={exportMarksWord}>
                <FileText className="h-4 w-4 mr-1" /> Download Word
              </Button>
            </div>
          </div>
          <div className="mb-3 relative max-w-sm">
            <Search className="h-4 w-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Tafuta kwa jina au Reg No..."
              value={marksSearch}
              onChange={(e) => setMarksSearch(e.target.value)}
              className="pl-8 h-9"
            />
          </div>
          {marks.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground text-sm">
              No mark rows yet. Click "Pull Students from Attempts" or use Import Excel above.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-muted/50 text-[10px] uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-2 py-2 text-left">Name of Student</th>
                    <th className="px-2 py-2 text-left">Reg No</th>
                    <th className="px-2 py-2 text-right">Test 1</th>
                    <th className="px-2 py-2 text-right">Test 2</th>
                    <th className="px-2 py-2 text-right">Presentation</th>
                    <th className="px-2 py-2 text-right">Contribution</th>
                    <th className="px-2 py-2 text-right">Total</th>
                    <th className="px-2 py-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {marks
                    .filter((m) => {
                      const q = marksSearch.trim().toLowerCase();
                      if (!q) return true;
                      return (
                        String(m.full_name || "").toLowerCase().includes(q) ||
                        String(m.reg_no || "").toLowerCase().includes(q)
                      );
                    })
                    .map((m) => {
                    const inputCls = "h-8 w-20 ml-auto font-mono-num text-right text-xs";
                    return (
                      <tr key={m.id} className="hover:bg-muted/30">
                        <td className="px-2 py-2 font-semibold">{m.full_name}</td>
                        <td className="px-2 py-2 font-mono-num">{m.reg_no}</td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.test1 ?? ""} onBlur={(e) => updateMark(m.id, "test1", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.test2 ?? ""} onBlur={(e) => updateMark(m.id, "test2", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.presentation ?? ""} onBlur={(e) => updateMark(m.id, "presentation", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2"><Input type="number" step="0.5" defaultValue={m.contribution ?? ""} onBlur={(e) => updateMark(m.id, "contribution", e.target.value)} className={inputCls} /></td>
                        <td className="px-2 py-2 text-right font-mono-num font-extrabold">{totalOf(m).toFixed(1)}</td>
                        <td className="px-2 py-2 text-right">
                          <Button size="sm" variant="ghost" onClick={() => removeMark(m.id)} className="text-destructive hover:text-destructive">
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {/* ============== Management (Password Protected) ============== */}
        <Card className="p-4 mb-6 shadow-card border-warning/40">
          <div className="flex items-center gap-2 mb-2">
            {mgmtAuth ? <ShieldCheck className="h-4 w-4 text-accent" /> : <Lock className="h-4 w-4 text-warning" />}
            <h2 className="font-bold">Hariri Matokeo (Password)</h2>
          </div>
          {!mgmtAuth ? (
            <div className="flex flex-wrap gap-2 items-end">
              <div className="flex-1 min-w-[200px]">
                <p className="text-xs text-muted-foreground mb-1">
                  Weka password ya management kuendelea.
                </p>
                <Input
                  type="password"
                  value={mgmtPwd}
                  onChange={(e) => setMgmtPwd(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && tryUnlockMgmt()}
                  placeholder="Management password"
                />
              </div>
              <Button size="sm" onClick={tryUnlockMgmt}>
                <Lock className="h-4 w-4 mr-1" /> Fungua
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Tafuta mwanafunzi kwa Reg No au jina kuhariri <b>alama</b> tu kwa mtihani huu. Mabadiliko yatashika moja kwa moja kwenye CSV/Excel/Word na ukurasa wa "Angalia Matokeo". Kwa marekebisho ya jina au Reg No tumia ukurasa wa <Link to="/admin/edit-requests" className="underline text-accent">Edit Requests</Link>.
              </p>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="h-4 w-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Reg No (mf. MUM2021-04-08738) au Jina kamili"
                    value={mgmtSearch}
                    onChange={(e) => setMgmtSearch(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && runMgmtSearch()}
                    className="pl-8"
                  />
                </div>
                <Button size="sm" onClick={runMgmtSearch} disabled={mgmtLoading}>
                  <Search className="h-4 w-4 mr-1" /> {mgmtLoading ? "Inatafuta..." : "Tafuta"}
                </Button>
              </div>
              {mgmtMatches.length > 0 && (
                <div className="overflow-x-auto border rounded-md">
                  <table className="w-full text-xs">
                    <thead className="bg-muted/50 text-[10px] uppercase tracking-widest text-muted-foreground">
                      <tr>
                        <th className="px-2 py-2 text-left">Jina</th>
                        <th className="px-2 py-2 text-left">Reg No</th>
                        <th className="px-2 py-2 text-right">Alama Mtihani</th>
                        <th className="px-2 py-2 text-right">T1</th>
                        <th className="px-2 py-2 text-right">T2</th>
                        <th className="px-2 py-2 text-right">Pres</th>
                        <th className="px-2 py-2 text-right">Contrib</th>
                        <th className="px-2 py-2 text-right">Hatua</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {mgmtMatches.map((s) => {
                        const isEditing = editId === s.id;
                        const numCls = "h-8 w-16 ml-auto font-mono-num text-right text-xs";
                        return (
                          <tr key={s.id} className="hover:bg-muted/30">
                            <td className="px-2 py-2">
                              <span className="font-semibold">{s.full_name}</span>
                            </td>
                            <td className="px-2 py-2 font-mono-num">
                              {s.exam_number}
                            </td>
                            <td className="px-2 py-2 text-right font-mono-num">
                              {isEditing && s.attempt ? (
                                <Input type="number" step="0.5" value={editMarks.score} onChange={(e) => setEditMarks({ ...editMarks, score: e.target.value })} className={numCls} />
                              ) : (
                                s.attempt ? `${s.attempt.score ?? "-"}/${s.attempt.total_marks ?? "-"}` : "—"
                              )}
                            </td>
                            <td className="px-2 py-2 text-right font-mono-num">
                              {isEditing ? (
                                <Input type="number" step="0.5" value={editMarks.test1} onChange={(e) => setEditMarks({ ...editMarks, test1: e.target.value })} className={numCls} />
                              ) : (s.mark?.test1 ?? "-")}
                            </td>
                            <td className="px-2 py-2 text-right font-mono-num">
                              {isEditing ? (
                                <Input type="number" step="0.5" value={editMarks.test2} onChange={(e) => setEditMarks({ ...editMarks, test2: e.target.value })} className={numCls} />
                              ) : (s.mark?.test2 ?? "-")}
                            </td>
                            <td className="px-2 py-2 text-right font-mono-num">
                              {isEditing ? (
                                <Input type="number" step="0.5" value={editMarks.presentation} onChange={(e) => setEditMarks({ ...editMarks, presentation: e.target.value })} className={numCls} />
                              ) : (s.mark?.presentation ?? "-")}
                            </td>
                            <td className="px-2 py-2 text-right font-mono-num">
                              {isEditing ? (
                                <Input type="number" step="0.5" value={editMarks.contribution} onChange={(e) => setEditMarks({ ...editMarks, contribution: e.target.value })} className={numCls} />
                              ) : (s.mark?.contribution ?? "-")}
                            </td>
                            <td className="px-2 py-2 text-right">
                              {isEditing ? (
                                <div className="flex gap-1 justify-end flex-wrap">
                                  <Button size="sm" onClick={() => saveMarksEdit(s)}>
                                    <Save className="h-3.5 w-3.5 mr-1" /> Hifadhi Alama
                                  </Button>
                                  <Button size="sm" variant="ghost" onClick={() => setEditId(null)}>
                                    Ghairi
                                  </Button>
                                </div>
                              ) : (
                                <Button size="sm" variant="outline" onClick={() => startEdit(s)}>
                                  Hariri Alama
                                </Button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </Card>

        {rows.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
            No students have taken this exam yet.
          </Card>
        ) : (
          <Card className="overflow-hidden shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-xs uppercase tracking-widest text-muted-foreground">
                  <tr>
                    <th className="px-4 py-3 text-left">Name</th>
                    <th className="px-4 py-3 text-left">Reg No</th>
                    <th className="px-4 py-3 text-right">Score</th>
                    <th className="px-4 py-3 text-center">Status</th>
                    <th className="px-4 py-3 text-left">Date</th>
                    <th className="px-4 py-3 text-left">Notes</th>
                    <th className="px-4 py-3 text-center">View</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.map((r) => {
                    const pct = r.total_marks > 0 ? Math.round(((r.score || 0) / r.total_marks) * 100) : 0;
                    return (
                      <tr key={r.id} className="hover:bg-muted/30">
                        <td className="px-4 py-3 font-semibold">
                          {r.students?.full_name}
                          {r.needs_grading && <span className="ml-2 text-[10px] px-1.5 py-0.5 rounded bg-warning/15 text-warning font-bold">GRADE</span>}
                        </td>
                        <td className="px-4 py-3 font-mono-num text-muted-foreground">{r.students?.exam_number}</td>
                        <td className="px-4 py-3 text-right font-mono-num font-bold">
                          {r.score ?? "-"}/{r.total_marks ?? "-"} <span className="text-muted-foreground text-xs">({pct}%)</span>
                        </td>
                        <td className="px-4 py-3 text-center">{statusBadge(r.status)}</td>
                        <td className="px-4 py-3 text-muted-foreground text-xs">
                          {r.submitted_at ? new Date(r.submitted_at).toLocaleString() : "—"}
                        </td>
                        <td className="px-4 py-3 text-xs text-warning">{r.violation_reason || ""}</td>
                        <td className="px-4 py-3 text-center">
                          <Button asChild size="sm" variant="ghost">
                            <Link to={`/admin/attempts/${r.id}`}><Eye className="h-3.5 w-3.5" /></Link>
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminResults;
