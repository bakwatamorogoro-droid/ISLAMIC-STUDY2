import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, XCircle, ArrowLeft, BookOpen, Search, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface Q {
  id: string;
  question_text: string;
  question_type: string;
  options: any;
  correct_answer: string | null;
  marks: number;
  position: number;
  student_answer: string | null;
  awarded: number | null;
}

const ExamRevision = () => {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const attemptId = params.get("attempt") || "";
  const [reg, setReg] = useState("");
  const [verified, setVerified] = useState(false);
  const [examTitle, setExamTitle] = useState("");
  const [questions, setQuestions] = useState<Q[]>([]);
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState<{ s: number; t: number } | null>(null);

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!attemptId) return toast.error("Link si sahihi.");
    setLoading(true);
    try {
      const { data: attempt } = await supabase
        .from("attempts")
        .select("id, score, total_marks, exam_id, students(exam_number, full_name), exams(title, results_published)")
        .eq("id", attemptId)
        .maybeSingle();
      if (!attempt) { toast.error("Attempt haijapatikana."); return; }
      const a: any = attempt;
      if (!a.exams?.results_published) {
        toast.error("Matokeo bado hayajachapishwa.");
        return;
      }
      if (a.students?.exam_number?.toLowerCase() !== reg.trim().toLowerCase()) {
        toast.error("Reg No haifanani na mtihani huu.");
        return;
      }
      setExamTitle(a.exams?.title || "");
      setScore({ s: a.score ?? 0, t: a.total_marks ?? 0 });

      const { data: qs } = await supabase
        .from("questions")
        .select("id, question_text, question_type, options, correct_answer, marks, position")
        .eq("exam_id", a.exam_id)
        .order("position", { ascending: true });

      const { data: ans } = await supabase
        .from("answers")
        .select("question_id, answer_text, awarded_marks")
        .eq("attempt_id", attemptId);

      const ansMap = new Map<string, any>();
      (ans || []).forEach((x: any) => ansMap.set(x.question_id, x));

      const merged: Q[] = (qs || []).map((q: any) => ({
        ...q,
        student_answer: ansMap.get(q.id)?.answer_text ?? null,
        awarded: ansMap.get(q.id)?.awarded_marks ?? null,
      }));
      setQuestions(merged);
      setVerified(true);
    } finally {
      setLoading(false);
    }
  };

  if (!verified) {
    return (
      <div className="min-h-screen bg-gradient-results text-foreground scene-3d grid place-items-center p-6">
        <Card className="max-w-md w-full p-6 bg-card shadow-elegant card-3d">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="h-6 w-6 text-accent" />
            <h1 className="font-extrabold text-xl text-foreground">Pitia Majibu Yako</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Andika Reg No yako kuthibitisha kabla ya kuona majibu.
          </p>
          <form onSubmit={verify} className="space-y-3">
            <div>
              <Label className="text-foreground">Reg No</Label>
              <Input value={reg} onChange={(e) => setReg(e.target.value.toUpperCase())} className="font-mono-num bg-white text-foreground" required />
            </div>
            <div className="flex gap-2">
              <Button asChild variant="outline" className="bg-card text-foreground border-border"><Link to="/results"><ArrowLeft className="h-4 w-4 mr-1" /> Rudi</Link></Button>
              <Button type="submit" className="flex-1 bg-primary text-primary-foreground" disabled={loading}>
                <Search className="h-4 w-4 mr-1" /> {loading ? "Inakagua…" : "Endelea"}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-results text-foreground scene-3d">
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container h-16 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Revision</div>
            <h1 className="font-extrabold text-lg text-primary">{examTitle}</h1>
          </div>
          <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold"><Link to="/results"><ArrowLeft className="h-4 w-4 mr-1" /> Matokeo</Link></Button>
        </div>
      </header>

      <div className="container py-8 max-w-3xl">
        {score && (
          <Card className="p-5 mb-6 bg-card card-3d text-center reveal-up">
            <div className="text-xs uppercase tracking-widest text-muted-foreground">Alama Yako</div>
            <div className="font-mono-num text-4xl font-extrabold text-primary">{score.s}<span className="text-xl text-muted-foreground">/{score.t}</span></div>
          </Card>
        )}

        <div className="flex items-center gap-2 mb-4 reveal-up">
          <Sparkles className="h-4 w-4 text-accent" />
          <p className="text-sm text-muted-foreground">Pitia kila swali — jibu lako vs jibu sahihi.</p>
        </div>

        <div className="space-y-4">
          {questions.map((q, i) => {
            const correct = q.correct_answer || "";
            const studentAns = q.student_answer || "";
            const isCorrect = q.awarded != null && q.awarded > 0;
            const opts = Array.isArray(q.options) ? q.options : [];
            const isMatching = q.question_type === "matching";
            return (
              <Card key={q.id} className={`p-5 bg-card card-3d shadow-card reveal-up border-l-4 ${isCorrect ? "border-l-accent" : "border-l-destructive"}`}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold">Swali {i + 1} · {q.marks} marks</div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${isCorrect ? "bg-accent/15 text-accent" : "bg-destructive/15 text-destructive"}`}>
                    {q.awarded != null ? `+${q.awarded}` : "0"}
                  </span>
                </div>
                <p className="font-semibold mb-3 text-foreground">{q.question_text}</p>

                {!isMatching && opts.length > 0 && (
                  <div className="space-y-1.5 mb-3">
                    {opts.map((o: string, idx: number) => {
                      const isC = o.toLowerCase() === correct.toLowerCase();
                      const isS = o.toLowerCase() === studentAns.toLowerCase();
                      return (
                        <div key={idx} className={`flex items-center gap-2 p-2 rounded-md text-sm ${
                          isC ? "bg-accent/10 border border-accent/30" :
                          isS ? "bg-destructive/10 border border-destructive/30" :
                          "bg-muted/30"
                        }`}>
                          {isC && <CheckCircle2 className="h-4 w-4 text-accent shrink-0" />}
                          {isS && !isC && <XCircle className="h-4 w-4 text-destructive shrink-0" />}
                          <span className={isC ? "font-bold text-accent" : isS ? "text-destructive line-through" : ""}>{o}</span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {isMatching && (() => {
                  let correctMap: Record<string, string> = {};
                  try { correctMap = JSON.parse(correct || "{}"); } catch {}
                  let studentMap: Record<string, string> = {};
                  try { studentMap = JSON.parse(studentAns || "{}"); } catch {}
                  return (
                    <div className="space-y-2 mb-3">
                      {Object.keys(correctMap).map((l, idx) => {
                        const right = correctMap[l];
                        const sR = studentMap[l] || "";
                        const ok = sR.trim().toLowerCase() === String(right).trim().toLowerCase();
                        return (
                          <div key={idx} className={`p-2 rounded-md text-sm border ${ok ? "bg-accent/10 border-accent/30" : "bg-destructive/10 border-destructive/30"}`}>
                            <div className="font-semibold text-foreground">{l}</div>
                            <div className="grid grid-cols-2 gap-2 mt-1 text-xs">
                              <div>
                                <span className="text-muted-foreground">Lako: </span>
                                <span className={ok ? "text-accent font-bold" : "text-destructive font-bold line-through"}>{sR || "—"}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Sahihi: </span>
                                <span className="text-accent font-bold">{right}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                {!isMatching && (
                  <div className="grid sm:grid-cols-2 gap-2 text-sm">
                    <div className="p-2 rounded-md bg-muted/40">
                      <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold mb-0.5">Jibu lako</div>
                      <div className={`font-semibold ${isCorrect ? "text-accent" : "text-destructive"}`}>{studentAns || "—"}</div>
                    </div>
                    <div className="p-2 rounded-md bg-accent/10">
                      <div className="text-[10px] uppercase tracking-widest text-accent font-bold mb-0.5">Jibu sahihi</div>
                      <div className="font-semibold text-accent">{correct || "—"}</div>
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ExamRevision;
