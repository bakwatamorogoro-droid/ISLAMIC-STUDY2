import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { GraduationCap, ShieldCheck, Clock, Lock, Shuffle, Eye, MapPin, FileText, Upload, Send, Loader2, CheckCircle2, Download, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import Countdown from "@/components/Countdown";
import { useI18n, LanguageToggle } from "@/lib/i18n";
import { toast } from "sonner";
import AnnouncementsTicker from "@/components/AnnouncementsTicker";
import SiteFooter from "@/components/SiteFooter";
import BrandLockup from "@/components/BrandLockup";

const featuresData = {
  sw: [
    { icon: ShieldCheck, title: "Anti-Cheat Otomatiki", desc: "Mfumo unakagua tab, full-screen na copy/paste — mwanafunzi akijaribu kudanganya, mtihani unawasilishwa mara moja." },
    { icon: Clock, title: "Timer Kali", desc: "Masaa, dakika na sekunde — hakuna pause, hakuna kuongeza muda." },
    { icon: Lock, title: "Kiosk Mode", desc: "Full screen lazima. Kutoka full-screen = kufungiwa." },
    { icon: Shuffle, title: "Maswali ya Random", desc: "Kila mwanafunzi anapata mpangilio tofauti wa maswali." },
    { icon: MapPin, title: "Kufuli ya GPS", desc: "Mtihani unafanyika tu ndani ya eneo lililowekwa na admin." },
    { icon: Eye, title: "Review Kabla ya Submit", desc: "Mwanafunzi anapitia majibu yote kabla ya kuwasilisha." },
  ],
  en: [
    { icon: ShieldCheck, title: "Automatic Anti-Cheat", desc: "The system monitors tabs, full-screen and copy/paste — any cheating attempt instantly submits the exam." },
    { icon: Clock, title: "Strict Timer", desc: "Hours, minutes, seconds — no pause, no extra time." },
    { icon: Lock, title: "Kiosk Mode", desc: "Full screen is required. Leaving full-screen = locked out." },
    { icon: Shuffle, title: "Randomized Questions", desc: "Every student gets a different question order." },
    { icon: MapPin, title: "GPS Lock", desc: "Exam can only be taken inside the area set by admin." },
    { icon: Eye, title: "Review Before Submit", desc: "Students review all answers before final submit." },
  ],
};

const stepsData = {
  sw: [
    "Mwanafunzi anajisajili kwa jina kamili na namba ya mtihani.",
    "GPS inathibitisha yupo ndani ya eneo la mtihani lililowekwa na admin.",
    "Mfumo unaingia full-screen mode na kufunga copy / paste / right-click.",
    "Akibadili tab au kutoka full-screen — auto-submit mara moja.",
    "Maswali yanachanganywa kwa mpangilio tofauti kwa kila mwanafunzi.",
    "MCQ na majibu mafupi yanasahihishwa otomatiki; insha inasahihishwa na admin.",
    "Admin anachapisha matokeo, mwanafunzi anayatazama kwa namba yake.",
  ],
  en: [
    "Student registers with full name and exam number.",
    "GPS verifies the student is inside the exam area set by admin.",
    "System enters full-screen mode and disables copy / paste / right-click.",
    "Switching tabs or leaving full-screen — auto-submits instantly.",
    "Questions are shuffled into a different order for each student.",
    "MCQ and short answers are auto-graded; essays are graded by admin.",
    "Admin publishes results; students view them with their number.",
  ],
};

interface Ann { id: string; title: string; body: string; created_at: string; }
interface UpcomingExam { id: string; title: string; scheduled_start_at: string; }
interface SeminarQ { id: string; title: string; description: string | null; pdf_url: string; created_at: string; }
interface RegisteredGroup {
  id: string;
  group_number: number;
  title: string | null;
  semester_title: string | null;
}
interface HomeSettings {
  hero_title: string;
  hero_subtitle: string;
  empty_exams_message: string;
  banner_image_url?: string | null;
}

const Index = () => {
  const { lang, t } = useI18n();
  const features = featuresData[lang];
  const steps = stepsData[lang];
  const [announcements, setAnnouncements] = useState<Ann[]>([]);
  const [upcoming, setUpcoming] = useState<UpcomingExam | null>(null);
  const [seminarQs, setSeminarQs] = useState<SeminarQ[]>([]);
  const [groupsList, setGroupsList] = useState<RegisteredGroup[]>([]);
  const [homeSettings, setHomeSettings] = useState<HomeSettings & { admin_email?: string; admin_phone?: string }>({ hero_title: "", hero_subtitle: "", empty_exams_message: "" });
  const [studentCount, setStudentCount] = useState<number>(0);
  const [examStats, setExamStats] = useState<{ taken: number; cheated: number; autoSubmitted: number }>({ taken: 0, cheated: 0, autoSubmitted: 0 });
  const [verifyReg, setVerifyReg] = useState("");
  const [verifyResult, setVerifyResult] = useState<{ status: "idle" | "found" | "missing"; data?: any }>({ status: "idle" });

  // Submission form
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("");
  const [leaderName, setLeaderName] = useState("");
  const [leaderPhone, setLeaderPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submittedOk, setSubmittedOk] = useState(false);

  useEffect(() => {
    (async () => {
      const { data: anns } = await supabase
        .from("announcements" as any)
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false })
        .limit(3);
      setAnnouncements((anns as any) || []);

      const nowIso = new Date().toISOString();
      const { data: exams } = await supabase
        .from("exams")
        .select("id,title,scheduled_start_at" as any)
        .gt("scheduled_start_at" as any, nowIso)
        .order("scheduled_start_at" as any, { ascending: true })
        .limit(1);
      if (exams && exams.length > 0) setUpcoming(exams[0] as any);

      const { data: qs } = await supabase
        .from("seminar_questions" as any)
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });
      setSeminarQs((qs as any) || []);

      // Load home settings (admin-editable hero/empty texts)
      const { data: hs } = await supabase
        .from("home_settings" as any)
        .select("hero_title, hero_subtitle, empty_exams_message, admin_email, admin_phone, admin_whatsapp, banner_image_url")
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (hs) setHomeSettings(hs as any);

      const { count } = await supabase.from("students").select("id", { count: "exact", head: true });
      setStudentCount(count || 0);

      const [{ count: takenC }, { count: cheatedC }, { count: autoC }] = await Promise.all([
        supabase.from("attempts").select("id", { count: "exact", head: true }).in("status", ["submitted", "auto_submitted", "terminated"]),
        supabase.from("attempts").select("id", { count: "exact", head: true }).eq("status", "terminated"),
        supabase.from("attempts").select("id", { count: "exact", head: true }).eq("status", "auto_submitted"),
      ]);
      setExamStats({ taken: takenC || 0, cheated: cheatedC || 0, autoSubmitted: autoC || 0 });

      // Load registered groups (with semester title) for the dropdown
      const { data: gs } = await supabase
        .from("groups")
        .select("id, group_number, title, semesters(title)")
        .order("group_number", { ascending: true });
      setGroupsList(
        ((gs as any) || []).map((g: any) => ({
          id: g.id,
          group_number: g.group_number,
          title: g.title,
          semester_title: g.semesters?.title ?? null,
        })),
      );
    })();
  }, []);

  const verifyRegistration = async (e: React.FormEvent) => {
    e.preventDefault();
    const reg = verifyReg.trim().toUpperCase();
    if (!reg) return;
    const { data } = await supabase.from("students").select("id, full_name, exam_number").ilike("exam_number", reg).maybeSingle();
    if (data) {
      // Angalia ikiwa ameshafanya mtihani wowote
      const { data: attempts } = await supabase
        .from("attempts")
        .select("status, exams(title)")
        .eq("student_id", (data as any).id)
        .in("status", ["submitted", "auto_submitted", "terminated"]);
      setVerifyResult({ status: "found", data: { ...data, attempts: (attempts as any[]) || [] } });
    } else {
      setVerifyResult({ status: "missing" });
    }
  };

  const onFile = (f: File | null) => {
    if (!f) { setPdfFile(null); return; }
    if (f.type !== "application/pdf") { toast.error(t("pdf_only")); return; }
    if (f.size > 20 * 1024 * 1024) { toast.error(t("pdf_too_large")); return; }
    setPdfFile(f);
  };

  const submitWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pdfFile) return toast.error(t("pdf_only"));
    const grp = groupsList.find((g) => g.id === selectedGroupId);
    if (!grp || !leaderName.trim()) return toast.error("!");
    setSubmitting(true);
    try {
      const path = `submissions/${Date.now()}-${pdfFile.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage.from("seminar-pdfs").upload(path, pdfFile, {
        contentType: "application/pdf", upsert: false,
      });
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("seminar-pdfs").getPublicUrl(path);
      const groupLabel = `Group ${grp.group_number}${grp.title ? " — " + grp.title : ""}`;
      const { error } = await supabase.from("group_submissions" as any).insert({
        group_name: groupLabel,
        semester: grp.semester_title,
        leader_name: leaderName.trim(),
        leader_phone: leaderPhone.trim() || null,
        notes: notes.trim() || null,
        pdf_url: pub.publicUrl,
      });
      if (error) throw error;
      toast.success(t("submission_success"));
      setSubmittedOk(true);
      setSelectedGroupId(""); setLeaderName(""); setLeaderPhone(""); setNotes(""); setPdfFile(null);
      if (fileRef.current) fileRef.current.value = "";
    } catch (err: any) {
      toast.error(err.message || "Error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur sticky top-0 z-40">
        <div className="container flex items-center justify-between h-14 md:h-16 gap-2">
          <BrandLockup variant="light" subtitle={t("brand_sub")} />
          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-2 flex-shrink-0">
            <LanguageToggle />
            <Button asChild variant="ghost" size="sm"><Link to="/results">{t("nav_results")}</Link></Button>
            <Button asChild variant="ghost" size="sm" className="text-accent"><Link to="/attendance">Attendance</Link></Button>
            <Button asChild variant="outline" size="sm"><Link to="/exam/signup">{t("nav_signup")}</Link></Button>
            <Button asChild size="sm"><Link to="/exam/register">{t("nav_exam")}</Link></Button>
          </nav>
          {/* Mobile nav — buttons muhimu tu */}
          <nav className="flex md:hidden items-center gap-1 flex-shrink-0">
            <LanguageToggle />
            <Button asChild variant="outline" size="sm" className="text-xs px-2"><Link to="/exam/register">{t("nav_exam")}</Link></Button>
          </nav>
        </div>
        {/* Mobile secondary nav bar */}
        <div className="md:hidden border-t border-border bg-card/60 px-3 py-1.5 flex items-center gap-2 overflow-x-auto text-xs">
          <Link to="/results" className="whitespace-nowrap text-muted-foreground hover:text-foreground px-2 py-1 rounded">{t("nav_results")}</Link>
          <Link to="/attendance" className="whitespace-nowrap text-accent hover:text-accent/80 px-2 py-1 rounded">Attendance</Link>
          <Link to="/exam/signup" className="whitespace-nowrap text-muted-foreground hover:text-foreground px-2 py-1 rounded">{t("nav_signup")}</Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-hero mesh-bg">
        {homeSettings.banner_image_url && (
          <div className="absolute inset-0 z-0" aria-hidden>
            <img
              src={homeSettings.banner_image_url}
              alt=""
              className="w-full h-full object-cover opacity-40"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-primary/60 via-primary/40 to-primary/80" />
          </div>
        )}
        <div className="absolute inset-0 opacity-15 z-0" style={{
          backgroundImage: "radial-gradient(circle at 20% 20%, white 1px, transparent 1px), radial-gradient(circle at 80% 60%, white 1px, transparent 1px)",
          backgroundSize: "60px 60px, 90px 90px"
        }} />
        {/* Floating decorative blobs */}
        <span className="blob bg-accent/40 h-72 w-72 -left-10 -top-10" />
        <span className="blob bg-primary-glow/40 h-80 w-80 right-0 top-20" style={{ animationDelay: "3s" }} />
        <span className="blob bg-accent-glow/30 h-64 w-64 left-1/3 bottom-0" style={{ animationDelay: "6s" }} />


        <div className="container relative z-10 py-12 md:py-28 text-center text-primary-foreground">
          {homeSettings.hero_subtitle?.trim() && (
            <div className="reveal-up inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-foreground/10 border border-primary-foreground/20 text-xs uppercase tracking-widest mb-6 backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-accent-glow animate-pulse" /> {homeSettings.hero_subtitle}
            </div>
          )}
          <h1 className="reveal-up reveal-up-d1 text-3xl md:text-6xl font-extrabold tracking-tight mb-3 max-w-3xl mx-auto text-3d">
            <span className="text-gradient-hero">{homeSettings.hero_title?.trim() || t("brand")}</span>
          </h1>
          <div className="reveal-up reveal-up-d2 mb-6 flex items-center justify-center gap-2 text-lg md:text-2xl font-bold tracking-wider">
            <span className="text-white/70">We are</span>
            <span className="rotating-words text-accent-glow font-extrabold">
              <span>SECURE</span>
              <span>MODERN</span>
              <span>FAST</span>
              <span>SMART</span>
              <span>SECURE</span>
            </span>
          </div>
          {upcoming ? (
            <div className="reveal-up reveal-up-d3 max-w-xl mx-auto mb-8 p-6 rounded-2xl glass-dark float-y">
              <div className="text-xs uppercase tracking-widest text-primary-foreground/70 mb-1">{t("upcoming_exam")}</div>
              <div className="font-bold text-lg mb-3">{upcoming.title}</div>
              <Countdown target={upcoming.scheduled_start_at} />
            </div>
          ) : homeSettings.empty_exams_message?.trim() ? (
            <p className="reveal-up reveal-up-d3 text-lg text-primary-foreground/85 mb-8 max-w-xl mx-auto whitespace-pre-line">
              {homeSettings.empty_exams_message}
            </p>
          ) : null}
          <div className="reveal-up reveal-up-d4 flex flex-wrap gap-3 justify-center">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground shadow-glow shimmer glow-pulse">
              <Link to="/exam/signup">{t("nav_signup")}</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 backdrop-blur">
              <Link to="/exam/register">{t("nav_exam")}</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Modern color band — kisasa accent strip below banner */}
      <div className="hero-color-band">
        <div className="container py-3 flex items-center justify-center gap-3 text-xs md:text-sm font-bold uppercase tracking-widest text-primary">
          <span className="h-1.5 w-1.5 rounded-full bg-accent animate-pulse" />
          <span className="text-foreground/80">Secure</span>
          <span className="opacity-30">·</span>
          <span className="text-accent">Modern</span>
          <span className="opacity-30">·</span>
          <span className="text-foreground/80">Trusted by IS Study MUM</span>
          <span className="h-1.5 w-1.5 rounded-full bg-primary-glow animate-pulse" />
        </div>
      </div>

      {/* Live news ticker (replaces simple announcements card) */}
      <AnnouncementsTicker />

      {/* Modern feature banner — student edit-request workflow */}
      <section className="container mt-6">
        <div className="max-w-4xl mx-auto">
          <Card className="p-5 border-accent/30 bg-gradient-to-r from-accent/10 via-primary/5 to-transparent shadow-elegant">
            <div className="flex items-start gap-3 flex-wrap">
              <div className="h-12 w-12 rounded-2xl bg-accent/15 text-accent grid place-items-center shrink-0">
                <Sparkles className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-[220px]">
                <div className="text-[10px] uppercase tracking-widest text-accent font-bold mb-1">
                  {lang === "sw" ? "Kipya kwenye mfumo" : "New on the system"}
                </div>
                <h3 className="font-extrabold text-lg leading-tight">
                  {lang === "sw"
                    ? "Omba marekebisho ya jina au Reg No moja kwa moja kwenye matokeo"
                    : "Request name or Reg No corrections directly from results"}
                </h3>
                <p className="text-xs text-muted-foreground mt-1">
                  {lang === "sw"
                    ? "Tafuta matokeo yako, kisha tuma ombi. Admin akiridhia, taarifa zinabadilika kila sehemu kiotomatiki."
                    : "Find your results, then submit a request. Once admin approves, your details update everywhere automatically."}
                </p>
              </div>
              <Button asChild size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground shadow-glow">
                <Link to="/results">{lang === "sw" ? "Nenda kwenye Matokeo" : "Go to Results"}</Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>

      {/* Students count + Registration verification */}
      <section className="container mt-8">
        <div className="grid md:grid-cols-2 gap-5 max-w-4xl mx-auto">
          <Card className="p-6 bg-gradient-card border-accent/30 shadow-elegant text-center">
            <div className="inline-flex h-12 w-12 rounded-2xl bg-accent/15 text-accent items-center justify-center mb-3">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div className="text-4xl md:text-5xl font-extrabold bg-gradient-hero bg-clip-text text-transparent font-mono-num">
              {studentCount}
            </div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground mt-1 font-bold">
              {lang === "sw" ? "Wanafunzi waliojisajili" : "Registered students"}
            </div>
          </Card>
          <Card className="p-6 shadow-card">
            <h3 className="font-bold mb-1 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" />
              {lang === "sw" ? "Thibitisha Usajili Wako" : "Verify Your Registration"}
            </h3>
            <p className="text-xs text-muted-foreground mb-3">
              {lang === "sw"
                ? "Andika namba yako ya mtihani kuthibitisha umejisajili."
                : "Enter your exam number to confirm you are registered."}
            </p>
            <form onSubmit={verifyRegistration} className="flex flex-col sm:flex-row gap-2">
              <Input
                value={verifyReg}
                onChange={(e) => setVerifyReg(e.target.value.toUpperCase())}
                placeholder={lang === "sw" ? "Namba ya mtihani" : "Exam number"}
                className="font-mono-num"
              />
              <Button type="submit" size="sm">{lang === "sw" ? "Thibitisha" : "Verify"}</Button>
            </form>
            {verifyResult.status === "found" && (
              <div className="mt-3 p-3 rounded-lg bg-accent/10 border border-accent/30 text-sm">
                <div className="flex items-center gap-2 font-bold text-accent">
                  <CheckCircle2 className="h-4 w-4" /> {lang === "sw" ? "Umesajiliwa" : "Registered"}
                </div>
                <div className="text-xs mt-1">
                  <b>{verifyResult.data.full_name}</b> — <span className="font-mono-num">{verifyResult.data.exam_number}</span>
                </div>
                {/* Onyesha historia ya mitihani iliyofanywa */}
                {verifyResult.data.attempts && verifyResult.data.attempts.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-accent/20">
                    <div className="text-[11px] uppercase tracking-wide text-accent font-semibold mb-1">
                      {lang === "sw" ? "Mitihani iliyofanywa:" : "Exams taken:"}
                    </div>
                    {verifyResult.data.attempts.map((a: any, i: number) => (
                      <div key={i} className="flex justify-between text-xs py-0.5">
                        <span>{a.exams?.title || "—"}</span>
                        <span className="text-muted-foreground capitalize">{a.status?.replace(/_/g, " ")}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            {verifyResult.status === "missing" && (
              <div className="mt-3 p-3 rounded-lg bg-destructive/10 border border-destructive/30 text-sm">
                <div className="font-bold text-destructive mb-1">
                  {lang === "sw" ? "Hujasajiliwa au umekosea" : "Not registered or wrong number"}
                </div>
                <div className="text-xs text-muted-foreground">
                  {lang === "sw" ? "Kama umekosea, wasiliana na admin:" : "If you made a mistake, contact admin:"}
                  {(homeSettings.admin_phone || homeSettings.admin_email || (homeSettings as any).admin_whatsapp) ? (
                    <div className="mt-1 font-semibold text-foreground">
                      {homeSettings.admin_phone && <div>📞 {homeSettings.admin_phone}</div>}
                      {(homeSettings as any).admin_whatsapp && <div>💬 WhatsApp: {(homeSettings as any).admin_whatsapp}</div>}
                      {homeSettings.admin_email && <div>✉️ {homeSettings.admin_email}</div>}
                    </div>
                  ) : <span className="ml-1">admin</span>}
                </div>
              </div>
            )}
          </Card>
        </div>
        <div className="grid grid-cols-3 gap-2 md:gap-3 max-w-4xl mx-auto mt-4">
          <Card className="p-4 text-center shadow-card">
            <div className="inline-flex h-10 w-10 rounded-xl bg-primary/10 text-primary items-center justify-center mb-2">
              <CheckCircle2 className="h-5 w-5" />
            </div>
            <div className="text-xl md:text-2xl lg:text-3xl font-extrabold font-mono-num">{examStats.taken}</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 font-bold">
              {lang === "sw" ? "Waliofanya Mtihani" : "Exams Taken"}
            </div>
          </Card>
          <Card className="p-4 text-center shadow-card">
            <div className="inline-flex h-10 w-10 rounded-xl bg-destructive/10 text-destructive items-center justify-center mb-2">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div className="text-xl md:text-2xl lg:text-3xl font-extrabold font-mono-num text-destructive">{examStats.cheated}</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 font-bold">
              {lang === "sw" ? "Waliodanganya" : "Cheating Cases"}
            </div>
          </Card>
          <Card className="p-4 text-center shadow-card">
            <div className="inline-flex h-10 w-10 rounded-xl bg-warning/10 text-warning items-center justify-center mb-2">
              <Clock className="h-5 w-5" />
            </div>
            <div className="text-xl md:text-2xl lg:text-3xl font-extrabold font-mono-num text-warning">{examStats.autoSubmitted}</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1 font-bold">
              {lang === "sw" ? "Mtihani Ulijituma (Muda)" : "Auto-Submitted (Time)"}
            </div>
          </Card>
        </div>
        <div className="max-w-4xl mx-auto mt-4 text-center">
          <Button
            size="sm"
            variant="outline"
            onClick={async () => {
              const pageSize = 1000;
              let from = 0;
              let all: any[] = [];
              while (true) {
                const { data, error } = await supabase
                  .from("attempts")
                  .select("score, total_marks, status, submitted_at, students(exam_number), exams(title, results_published)")
                  .order("submitted_at", { ascending: false })
                  .range(from, from + pageSize - 1);
                if (error) break;
                const chunk = (data as any[]) || [];
                all = all.concat(chunk);
                if (chunk.length < pageSize) break;
                from += pageSize;
              }
              const rows = all.filter((r: any) => r.exams?.results_published);
              if (!rows.length) { toast.error(lang === "sw" ? "Hakuna matokeo yaliyochapishwa." : "No published results."); return; }
              const doc = new jsPDF({ orientation: "landscape" });
              doc.setFontSize(16); doc.setFont("helvetica", "bold");
              doc.text("ISLAMIC STUDIES MUM — General Results", 14, 15);
              doc.setFontSize(10); doc.setFont("helvetica", "normal");
              doc.text(`${new Date().toLocaleString()}  ·  Jumla: ${rows.length}`, 14, 22);
              autoTable(doc, {
                startY: 28,
                head: [["#", "Reg No", "Mtihani", "Alama", "Asilimia", "Hali"]],
                body: rows.map((r: any, i: number) => {
                  const pct = r.total_marks > 0 ? Math.round(((r.score || 0) / r.total_marks) * 100) + "%" : "—";
                  return [
                    i + 1,
                    r.students?.exam_number || "—",
                    r.exams?.title || "—",
                    `${r.score ?? 0}/${r.total_marks ?? 0}`,
                    pct,
                    String(r.status || "").replace("_", " "),
                  ];
                }),
                styles: { fontSize: 9, cellPadding: 2 },
                headStyles: { fillColor: [15, 35, 70], textColor: 255, fontStyle: "bold" },
                alternateRowStyles: { fillColor: [245, 247, 250] },
              });
              doc.save(`IS_STUDY_MUM_General_Results_${new Date().toISOString().slice(0, 10)}.pdf`);
            }}
          >
            <Download className="h-4 w-4 mr-2" />
            {lang === "sw" ? "Pakua General Results PDF" : "Download General Results PDF"}
          </Button>
          <p className="text-[11px] text-muted-foreground mt-2">
            {lang === "sw"
              ? "Inaonesha Reg No, Alama na Hali ya kila mwanafunzi (bila majina)."
              : "Shows Reg No, Score and Status per student (no names)."}
          </p>
        </div>
      </section>

      {/* Upcoming exam card */}
      {upcoming && (
        <section className="container mt-6 relative z-10">
          <div className="max-w-2xl mx-auto">
            <Card className="p-6 bg-gradient-card border-accent/30 shadow-elegant">
              <div className="flex items-start gap-3 mb-3">
                <div className="h-10 w-10 rounded-xl bg-accent/10 text-accent grid place-items-center shrink-0">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold">{upcoming.title}</h3>
                  <p className="text-xs text-muted-foreground">{t("upcoming_exam")}</p>
                </div>
              </div>
              <Countdown target={upcoming.scheduled_start_at} />
            </Card>
          </div>
        </section>
      )}

      {/* Seminar Question Papers — colorful & animated */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-primary/5 pointer-events-none" />
        <div className="container relative">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex h-14 w-14 rounded-2xl bg-gradient-accent text-accent-foreground items-center justify-center mb-4 shadow-glow animate-pulse">
              <FileText className="h-7 w-7" />
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold mb-2 bg-gradient-hero bg-clip-text text-transparent">
              {t("seminar_questions")}
            </h2>
            <p className="text-muted-foreground">{t("seminar_questions_sub")}</p>
          </div>
          {seminarQs.length === 0 ? (
            <Card className="p-10 text-center text-muted-foreground max-w-2xl mx-auto">
              <FileText className="h-10 w-10 mx-auto mb-3 opacity-40" />
              {t("no_seminar_questions")}
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-6xl mx-auto">
              {seminarQs.map((q, i) => (
                <Card
                  key={q.id}
                  className="group relative p-5 shadow-card hover:shadow-elegant transition-smooth overflow-hidden border-accent/20 hover:-translate-y-1"
                  style={{ animation: `fadeInUp 0.5s ease-out ${i * 80}ms both` }}
                >
                  <div className="absolute top-0 right-0 h-20 w-20 rounded-full bg-accent/10 -mr-8 -mt-8 group-hover:bg-accent/20 transition-smooth" />
                  <div className="relative flex items-start gap-3 mb-4">
                    <div className="h-12 w-12 rounded-xl bg-gradient-hero grid place-items-center text-primary-foreground shrink-0 shadow-elegant group-hover:rotate-6 transition-smooth">
                      <FileText className="h-6 w-6" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest text-accent mb-1">
                        <Sparkles className="h-3 w-3" /> {lang === "sw" ? "Mpya" : "New"}
                      </div>
                      <h3 className="font-bold leading-tight">{q.title}</h3>
                      {q.description && <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{q.description}</p>}
                    </div>
                  </div>
                  <Button asChild size="sm" className="w-full bg-gradient-accent hover:opacity-90 text-accent-foreground">
                    <a href={q.pdf_url} target="_blank" rel="noopener noreferrer">
                      <Download className="h-4 w-4 mr-1" /> {t("download")} PDF
                    </a>
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
        <style>{`@keyframes fadeInUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }`}</style>
      </section>

      {/* Submit Group Work */}
      <section className="container pb-16">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-6">
            <div className="inline-flex h-12 w-12 rounded-2xl bg-accent/10 text-accent items-center justify-center mb-3">
              <Upload className="h-6 w-6" />
            </div>
            <h2 className="text-2xl md:text-3xl font-extrabold mb-2">{t("submit_group_work")}</h2>
            <p className="text-muted-foreground text-sm">{t("submit_group_work_sub")}</p>
          </div>
          <Card className="p-6 shadow-card">
            {submittedOk && (
              <div className="mb-4 p-3 rounded-lg bg-accent/10 border border-accent/30 flex items-center gap-2 text-sm font-semibold text-accent">
                <CheckCircle2 className="h-4 w-4" /> {t("submission_success")}
              </div>
            )}
            <form onSubmit={submitWork} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-3">
                <div className="md:col-span-2">
                  <Label>{t("group_name")}</Label>
                  {groupsList.length === 0 ? (
                    <Input disabled placeholder={lang === "sw" ? "Hakuna group lililosajiliwa bado" : "No registered groups yet"} />
                  ) : (
                    <select
                      value={selectedGroupId}
                      onChange={(e) => setSelectedGroupId(e.target.value)}
                      required
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                    >
                      <option value="">{t("choose_dash")}</option>
                      {groupsList.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.semester_title ? `${g.semester_title} — ` : ""}Group {g.group_number}
                          {g.title ? ` — ${g.title}` : ""}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
                <div>
                  <Label>{t("leader_name")}</Label>
                  <Input value={leaderName} onChange={(e) => setLeaderName(e.target.value)} required placeholder="John Doe" />
                </div>
                <div>
                  <Label>{t("leader_phone")} {t("optional")}</Label>
                  <Input value={leaderPhone} onChange={(e) => setLeaderPhone(e.target.value)} placeholder="07XXXXXXXX" className="font-mono-num" />
                </div>
              </div>
              <div>
                <Label>{t("notes_optional")}</Label>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
              </div>
              <div>
                <Label>{t("pdf_file")}</Label>
                <Input ref={fileRef} type="file" accept="application/pdf" onChange={(e) => onFile(e.target.files?.[0] || null)} required />
                {pdfFile && <p className="text-xs text-muted-foreground mt-1 truncate">📎 {pdfFile.name}</p>}
              </div>
              <Button type="submit" className="w-full" disabled={submitting || !pdfFile || !selectedGroupId}>
                {submitting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> {t("submitting")}</>) : (<><Send className="h-4 w-4 mr-2" /> {t("submit")}</>)}
              </Button>
            </form>
          </Card>
        </div>
      </section>

      {/* Features */}
      <section className="container py-12">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">{t("features_title")}</h2>
          <p className="text-muted-foreground">{t("features_sub")}</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f) => (
            <div key={f.title} className="group p-6 rounded-2xl bg-gradient-card border border-border shadow-card hover:shadow-elegant transition-smooth">
              <div className="h-11 w-11 rounded-xl bg-accent/10 text-accent grid place-items-center mb-4 group-hover:bg-accent group-hover:text-accent-foreground transition-smooth">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-bold text-lg mb-1">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="container pb-20 max-w-3xl">
        <h2 className="text-3xl md:text-4xl font-extrabold mb-6 text-center">{t("how_title")}</h2>
        <ol className="space-y-3 text-sm">
          {steps.map((step, i) => (
            <li key={i} className="flex gap-3 p-4 rounded-xl bg-card border border-border">
              <span className="shrink-0 h-7 w-7 rounded-full bg-accent text-accent-foreground grid place-items-center font-bold text-sm">{i + 1}</span>
              <span className="pt-0.5 text-muted-foreground">{step}</span>
            </li>
          ))}
        </ol>
      </section>

      {/* CTA */}
      <section className="container pb-24">
        <div className="rounded-3xl bg-gradient-hero p-10 md:p-16 text-primary-foreground text-center shadow-elegant">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-3">{t("cta_title")}</h2>
          <p className="text-primary-foreground/80 mb-6 max-w-xl mx-auto">
            {t("cta_sub")}
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <Link to="/exam/signup">{t("nav_signup")}</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="bg-transparent border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10">
              <Link to="/exam/register">{t("nav_exam")}</Link>
            </Button>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
};

export default Index;
