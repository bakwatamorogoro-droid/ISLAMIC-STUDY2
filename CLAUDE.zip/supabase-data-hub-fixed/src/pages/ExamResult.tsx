import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle2, XCircle, AlertTriangle, Home, ClipboardX } from "lucide-react";

interface Result { score: number; total: number; status: string; reason?: string; needsGrading?: boolean; attemptId?: string; }

const ExamResult = () => {
  const navigate = useNavigate();
  const [result, setResult] = useState<Result | null>(null);

  useEffect(() => {
    const r = sessionStorage.getItem("isStudyMum_result");
    if (!r) { navigate("/"); return; }
    setResult(JSON.parse(r));
    sessionStorage.removeItem("isStudyMum_student");
  }, [navigate]);

  if (!result) return null;

  const pct = result.total > 0 ? Math.round((result.score / result.total) * 100) : 0;
  const passed = pct >= 50;
  const isTerminated = result.status === "terminated";
  const isAutoSubmit = result.status === "auto_submitted";
  const isAbnormal = isTerminated || isAutoSubmit;

  // Amalizia vs Hakukamilisha
  // "terminated" = alisimamishwa kwa ukiukaji → hakukamilisha
  // "auto_submitted" = muda uliisha → pia hakukamilisha kikamilifu
  const didNotComplete = isTerminated;

  const Icon = didNotComplete ? ClipboardX : isAbnormal ? AlertTriangle : passed ? CheckCircle2 : XCircle;
  const colorClass = didNotComplete
    ? "text-destructive"
    : isAbnormal
    ? "text-warning"
    : passed
    ? "text-accent"
    : "text-destructive";

  const headingText = didNotComplete
    ? "Haukukamilisha Mtihani"
    : isAutoSubmit
    ? "Mtihani Umewasilishwa Otomatiki (Muda Uliisha)"
    : "Mtihani Umewasilishwa";

  return (
    <div className="min-h-screen bg-gradient-exam text-foreground grid place-items-center p-6 scene-3d">
      <Card className="max-w-md w-full p-8 text-center shadow-elegant card-3d float-3d bg-card">
        <div className={`inline-flex h-20 w-20 rounded-full bg-current/10 items-center justify-center mb-4 ${colorClass}`}>
          <Icon className="h-10 w-10" />
        </div>
        <h1 className="text-2xl font-extrabold mb-1">{headingText}</h1>

        {result.reason && (
          <p className={`text-sm mb-4 ${didNotComplete ? "text-destructive" : "text-warning"}`}>
            Sababu: {result.reason}
          </p>
        )}

        <div className="my-6 py-6 border-y border-border">
          {didNotComplete ? (
            // Alisimamishwa — onesha ujumbe wazi
            <div className="space-y-3">
              <div className="text-xs uppercase text-destructive tracking-widest mb-1 font-bold">
                Mtihani Haukukamilika
              </div>
              <p className="text-sm text-muted-foreground">
                Mtihani wako ulisimamishwa kabla ya kumalizia.{" "}
                {result.reason && <span>Sababu: <strong>{result.reason}</strong>.</span>}
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Tafadhali wasiliana na msimamizi wa mtihani kupata msaada zaidi.
              </p>
            </div>
          ) : result.needsGrading ? (
            // Ana maswali ya insha yanayosubiri kupimwa
            <>
              <div className="text-xs uppercase text-warning tracking-widest mb-1 font-bold">
                Inasubiri Kupimwa na Admin
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Mtihani wako una maswali ya insha. Admin atayapima na kuchapisha matokeo.
                Tafadhali angalia matokeo baadaye kwa namba yako ya usajili.
              </p>
            </>
          ) : (
            // Amekamilisha vizuri
            <>
              <div className="text-xs uppercase text-muted-foreground tracking-widest mb-1">
                Alama (Sehemu Iliyojipima Otomatiki)
              </div>
              <div className="font-mono-num text-5xl font-extrabold">
                {result.score}<span className="text-2xl text-muted-foreground">/{result.total}</span>
              </div>
              <div className={`text-lg font-bold mt-2 ${colorClass}`}>{pct}%</div>
              <p className="text-xs text-muted-foreground mt-2">Matokeo rasmi yatachapishwa na admin.</p>
            </>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button asChild variant="outline"><Link to="/results">Angalia Matokeo</Link></Button>
          <Button asChild><Link to="/"><Home className="h-4 w-4 mr-2" /> Nyumbani</Link></Button>
        </div>
      </Card>
    </div>
  );
};

export default ExamResult;
