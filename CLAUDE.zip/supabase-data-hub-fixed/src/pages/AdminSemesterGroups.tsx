// @ts-nocheck
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Trash2, Users, FileSpreadsheet, ChevronRight, Edit3, MapPin, Loader2 } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { Switch } from "@/components/ui/switch";
import { getCurrentPosition } from "@/lib/geo";
import { useI18n, LanguageToggle } from "@/lib/i18n";
import * as XLSX from "xlsx";

const GROUP_OPTIONS = Array.from({ length: 20 }, (_, i) => i + 1);

const AdminSemesterGroups = () => {
  const { semesterId } = useParams();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [semester, setSemester] = useState<any>(null);
  const [groups, setGroups] = useState<any[]>([]);
  const [memberCounts, setMemberCounts] = useState<Record<string, number>>({});
  const [groupNumber, setGroupNumber] = useState<number>(1);
  const [groupTitle, setGroupTitle] = useState("");
  const [maxScore, setMaxScore] = useState<number>(20);
  const [groupScore, setGroupScore] = useState<string>("");
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [locationRequired, setLocationRequired] = useState(false);
  const [locLat, setLocLat] = useState("");
  const [locLng, setLocLng] = useState("");
  const [locRadius, setLocRadius] = useState<number>(200);
  const [studentLimit, setStudentLimit] = useState<string>("");
  const [pickingLoc, setPickingLoc] = useState(false);

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, [semesterId]);

  const load = async () => {
    const { data: sem } = await supabase.from("semesters").select("*").eq("id", semesterId).single();
    setSemester(sem);
    const { data: gs } = await supabase.from("groups").select("*").eq("semester_id", semesterId).order("group_number");
    setGroups((gs as any) || []);
    if (gs && gs.length > 0) {
      const { data: mems } = await supabase.from("group_members").select("group_id").in("group_id", gs.map((g: any) => g.id));
      const counts: Record<string, number> = {};
      (mems || []).forEach((m: any) => { counts[m.group_id] = (counts[m.group_id] || 0) + 1; });
      setMemberCounts(counts);
    }
  };

  const saveGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload: any = {
      semester_id: semesterId,
      group_number: groupNumber,
      title: groupTitle.trim() || null,
      max_score: maxScore,
      group_score: groupScore !== "" ? parseFloat(groupScore) : null,
      location_required: locationRequired,
      location_lat: locationRequired && locLat ? parseFloat(locLat) : null,
      location_lng: locationRequired && locLng ? parseFloat(locLng) : null,
      location_radius_m: locRadius || 200,
      student_limit: studentLimit !== "" ? parseInt(studentLimit) : null,
    };
    if (editingGroupId) {
      const { error } = await supabase.from("groups").update(payload).eq("id", editingGroupId);
      if (error) return toast.error(error.message);
      toast.success("OK");
    } else {
      const { error } = await supabase.from("groups").insert(payload);
      if (error) return toast.error(error.message);
      toast.success("OK");
    }
    setGroupTitle(""); setGroupScore(""); setMaxScore(20); setEditingGroupId(null);
    setLocationRequired(false); setLocLat(""); setLocLng(""); setLocRadius(200);
    setStudentLimit("");
    load();
  };

  const editGroup = (g: any) => {
    setEditingGroupId(g.id);
    setGroupNumber(g.group_number);
    setGroupTitle(g.title || "");
    setMaxScore(Number(g.max_score) || 20);
    setGroupScore(g.group_score != null ? String(g.group_score) : "");
    setLocationRequired(!!g.location_required);
    setLocLat(g.location_lat != null ? String(g.location_lat) : "");
    setLocLng(g.location_lng != null ? String(g.location_lng) : "");
    setLocRadius(g.location_radius_m || 200);
    setStudentLimit(g.student_limit != null ? String(g.student_limit) : "");
  };

  const pickCurrentLocation = async () => {
    setPickingLoc(true);
    try {
      const pos = await getCurrentPosition();
      setLocLat(String(pos.lat));
      setLocLng(String(pos.lng));
      toast.success(`OK (~${Math.round(pos.accuracy)}m)`);
    } catch (e: any) {
      toast.error(e.message || "Error");
    } finally {
      setPickingLoc(false);
    }
  };

  const removeGroup = async (id: string) => {
    if (!confirm("Delete? / Futa?")) return;
    const { error } = await supabase.from("groups").delete().eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  const exportAllToExcel = async () => {
    const { data: gs } = await supabase.from("groups").select("*").eq("semester_id", semesterId).order("group_number");
    if (!gs || gs.length === 0) return toast.error("No groups");
    const { data: members } = await supabase.from("group_members").select("*").in("group_id", gs.map((g: any) => g.id));

    const rows: any[] = [];
    gs.forEach((g: any) => {
      const ms = (members || []).filter((m: any) => m.group_id === g.id);
      ms.forEach((m: any, i: number) => {
        rows.push({
          "Group #": g.group_number,
          "Title": g.title || "",
          "#": i + 1,
          "Full Name": m.full_name,
          "Reg No": m.reg_no,
          "Mobile": m.mobile_no || "",
          "Indiv": m.individual_score ?? "",
          "Group Marks": g.group_score ?? "",
          "Max": g.max_score,
          "Final": m.individual_score ?? g.group_score ?? "",
        });
      });
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [{ wch: 8 }, { wch: 22 }, { wch: 4 }, { wch: 28 }, { wch: 18 }, { wch: 14 }, { wch: 8 }, { wch: 12 }, { wch: 6 }, { wch: 8 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Marks");
    XLSX.writeFile(wb, `${(semester?.title || "Seminar").replace(/\s+/g, "_")}_Marks.xlsx`);
  };

  if (!semester) return null;

  const usedNumbers = new Set(groups.filter((g) => g.id !== editingGroupId).map((g) => g.group_number));

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-4">
          <Link to="/admin/semesters" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> {t("semesters")}
          </Link>
          <LanguageToggle />
        </div>
        <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-extrabold">{semester.title}</h1>
            <p className="text-sm text-muted-foreground">{t("groups")} ({groups.length}/20)</p>
          </div>
          <Button variant="outline" onClick={exportAllToExcel} disabled={groups.length === 0}>
            <FileSpreadsheet className="h-4 w-4 mr-1" /> {t("export_excel")}
          </Button>
        </div>

        <Card className="p-6 mb-6 shadow-card">
          <h2 className="font-bold mb-4">{editingGroupId ? t("edit_group") : t("add_group")}</h2>
          <form onSubmit={saveGroup} className="grid md:grid-cols-5 gap-3 items-end">
            <div>
              <Label>Group #</Label>
              <select value={groupNumber} onChange={(e) => setGroupNumber(+e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm font-mono-num">
                {GROUP_OPTIONS.map((n) => (
                  <option key={n} value={n} disabled={usedNumbers.has(n)}>
                    Group {n}{usedNumbers.has(n) ? ` (${t("used_already")})` : ""}
                  </option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <Label>{t("group_title")}</Label>
              <Input value={groupTitle} onChange={(e) => setGroupTitle(e.target.value)} placeholder="Database Design" />
            </div>
            <div>
              <Label>{t("group_marks")}</Label>
              <Input type="number" step="0.5" value={groupScore} onChange={(e) => setGroupScore(e.target.value)}
                placeholder="—" className="font-mono-num" />
            </div>
            <div>
              <Label>{t("max")}</Label>
              <Input type="number" step="0.5" value={maxScore} onChange={(e) => setMaxScore(+e.target.value || 20)}
                className="font-mono-num" />
            </div>
            <div>
              <Label>{t("student_limit")}</Label>
              <Input type="number" min={1} value={studentLimit} onChange={(e) => setStudentLimit(e.target.value)}
                placeholder="∞" className="font-mono-num" />
            </div>
            <div className="md:col-span-5 border-t border-border pt-4 mt-2">
              <div className="flex items-center gap-2 mb-3">
                <Switch id="locreq" checked={locationRequired} onCheckedChange={setLocationRequired} />
                <Label htmlFor="locreq" className="cursor-pointer flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-accent" />
                  {t("gps_required_toggle")}
                </Label>
              </div>
              {locationRequired && (
                <div className="grid md:grid-cols-4 gap-3 items-end bg-muted/40 p-3 rounded-lg">
                  <div>
                    <Label className="text-xs">{t("latitude")}</Label>
                    <Input value={locLat} onChange={(e) => setLocLat(e.target.value)} placeholder="-6.7924" className="font-mono-num" />
                  </div>
                  <div>
                    <Label className="text-xs">{t("longitude")}</Label>
                    <Input value={locLng} onChange={(e) => setLocLng(e.target.value)} placeholder="39.2083" className="font-mono-num" />
                  </div>
                  <div>
                    <Label className="text-xs">{t("radius_m")}</Label>
                    <Input type="number" min={10} step={10} value={locRadius} onChange={(e) => setLocRadius(+e.target.value || 200)} className="font-mono-num" />
                  </div>
                  <Button type="button" variant="outline" onClick={pickCurrentLocation} disabled={pickingLoc}>
                    {pickingLoc ? <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> {t("picking")}</> : <><MapPin className="h-4 w-4 mr-1" /> {t("use_my_location")}</>}
                  </Button>
                </div>
              )}
            </div>
            <div className="md:col-span-5 flex gap-2">
              <Button type="submit">{editingGroupId ? t("update") : t("add")}</Button>
              {editingGroupId && (
                <Button type="button" variant="ghost" onClick={() => { setEditingGroupId(null); setGroupTitle(""); setGroupScore(""); setMaxScore(20); setLocationRequired(false); setLocLat(""); setLocLng(""); setLocRadius(200); setStudentLimit(""); }}>
                  {t("cancel")}
                </Button>
              )}
            </div>
          </form>
        </Card>

        {groups.length === 0 ? (
          <Card className="p-12 text-center text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
            {t("no_groups_yet")}
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {groups.map((g) => (
              <Card key={g.id} className="p-5 shadow-card">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="min-w-0">
                    <div className="text-xs uppercase tracking-widest text-muted-foreground">Group {g.group_number}</div>
                    <h3 className="font-bold">{g.title || "—"}</h3>
                    <div className="text-sm text-muted-foreground mt-1 font-mono-num">
                      {t("group_marks")}: <span className="text-foreground font-semibold">{g.group_score ?? "—"}/{g.max_score}</span> · {memberCounts[g.id] || 0}{g.student_limit ? `/${g.student_limit}` : ""} {t("students_word")}
                    </div>
                    {g.student_limit != null && (memberCounts[g.id] || 0) >= g.student_limit && (
                      <div className="mt-1 text-xs text-destructive font-semibold">⚠ {t("group_full")}</div>
                    )}
                    {g.location_required && (
                      <div className="mt-1 text-xs text-accent flex items-center gap-1">
                        <MapPin className="h-3 w-3" /> GPS: {g.location_radius_m}m
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 flex-wrap mt-4">
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/admin/groups/${g.id}/members`}><Users className="h-3.5 w-3.5 mr-1" /> {t("members_link")} <ChevronRight className="h-3.5 w-3.5" /></Link>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => editGroup(g)}><Edit3 className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => removeGroup(g.id)} className="text-destructive hover:text-destructive">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};


export default AdminSemesterGroups;
