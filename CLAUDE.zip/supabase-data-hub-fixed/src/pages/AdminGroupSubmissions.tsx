import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, Inbox, ExternalLink, Trash2, CheckCircle2, Phone, Save } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";
import { LanguageToggle } from "@/lib/i18n";

interface Sub {
  id: string; group_name: string; semester: string | null;
  leader_name: string; leader_phone: string | null;
  pdf_url: string; notes: string | null; admin_notes: string | null;
  status: string; reviewed: boolean; created_at: string;
}

const AdminGroupSubmissions = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<Sub[]>([]);
  const [draft, setDraft] = useState<Record<string, string>>({});

  useEffect(() => {
    verifyAdmin().then((a) => {
      if (!a) { navigate("/admin/login"); return; }
      load();
    });
  }, []);

  const load = async () => {
    const { data } = await supabase.from("group_submissions" as any).select("*").order("created_at", { ascending: false });
    setItems((data as any) || []);
  };

  const markReviewed = async (s: Sub) => {
    const { error } = await supabase.from("group_submissions" as any).update({
      reviewed: !s.reviewed, status: !s.reviewed ? "reviewed" : "pending",
    }).eq("id", s.id);
    if (error) return toast.error(error.message);
    load();
  };

  const saveNotes = async (s: Sub) => {
    const note = draft[s.id] ?? s.admin_notes ?? "";
    const { error } = await supabase.from("group_submissions" as any).update({ admin_notes: note }).eq("id", s.id);
    if (error) return toast.error(error.message);
    toast.success("Saved");
    load();
  };

  const remove = async (s: Sub) => {
    if (!confirm("Delete this submission?")) return;
    const { error } = await supabase.from("group_submissions" as any).delete().eq("id", s.id);
    if (error) return toast.error(error.message);
    load();
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-4">
          <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-4 w-4" /> Admin
          </Link>
          <LanguageToggle />
        </div>
        <h1 className="text-2xl font-extrabold mb-1">Group Submissions</h1>
        <p className="text-sm text-muted-foreground mb-6">Work uploaded by groups from the home page.</p>

        {items.length === 0 ? (
          <Card className="p-10 text-center text-muted-foreground">
            <Inbox className="h-10 w-10 mx-auto mb-3 opacity-40" /> No submissions yet.
          </Card>
        ) : (
          <div className="space-y-4">
            {items.map((s) => (
              <Card key={s.id} className="p-5 shadow-card">
                <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold">{s.group_name}</h3>
                      {s.semester && <span className="text-xs px-2 py-0.5 rounded-full bg-muted">{s.semester}</span>}
                      <span className={`text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full ${
                        s.reviewed ? "bg-accent/15 text-accent" : "bg-warning/15 text-warning"
                      }`}>{s.reviewed ? "Reviewed" : "Pending"}</span>
                    </div>
                    <div className="text-sm text-muted-foreground mt-1">
                      Leader: <span className="text-foreground font-semibold">{s.leader_name}</span>
                      {s.leader_phone && (
                        <a href={`tel:${s.leader_phone}`} className="inline-flex items-center gap-1 ml-3 text-accent font-mono-num">
                          <Phone className="h-3 w-3" /> {s.leader_phone}
                        </a>
                      )}
                    </div>
                    <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
                      {new Date(s.created_at).toLocaleString()}
                    </div>
                    {s.notes && <p className="text-xs italic text-muted-foreground mt-2">"{s.notes}"</p>}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button asChild size="sm" variant="outline">
                      <a href={s.pdf_url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-3.5 w-3.5 mr-1" /> Open PDF
                      </a>
                    </Button>
                    <Button size="sm" variant={s.reviewed ? "ghost" : "default"} onClick={() => markReviewed(s)}>
                      <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> {s.reviewed ? "Undo" : "Mark Reviewed"}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(s)} className="text-destructive hover:text-destructive">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="border-t border-border pt-3 mt-3">
                  <label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Admin Notes / Feedback</label>
                  <Textarea
                    rows={2}
                    defaultValue={s.admin_notes || ""}
                    onChange={(e) => setDraft((d) => ({ ...d, [s.id]: e.target.value }))}
                    placeholder="Write feedback for the group..."
                    className="mt-1"
                  />
                  <Button size="sm" className="mt-2" onClick={() => saveNotes(s)}>
                    <Save className="h-3.5 w-3.5 mr-1" /> Save Notes
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminGroupSubmissions;
