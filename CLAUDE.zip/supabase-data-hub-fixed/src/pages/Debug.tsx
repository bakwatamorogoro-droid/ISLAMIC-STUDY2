import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

type Check = { name: string; ok: boolean | null; detail: string };

export default function Debug() {
  const projectId = import.meta.env.VITE_SUPABASE_PROJECT_ID as string;
  const url = import.meta.env.VITE_SUPABASE_URL as string;
  const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;
  const [checks, setChecks] = useState<Check[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const results: Check[] = [];

      // 1. REST ping
      try {
        const r = await fetch(`${url}/rest/v1/`, { headers: { apikey: key } });
        results.push({ name: "REST endpoint", ok: r.ok, detail: `HTTP ${r.status}` });
      } catch (e: any) {
        results.push({ name: "REST endpoint", ok: false, detail: e.message });
      }

      // 2. Tables
      const tables = ["students", "exams", "student_edit_requests", "home_settings"];
      for (const t of tables) {
        const { error } = await supabase.from(t as any).select("*", { count: "exact", head: true });
        results.push({
          name: `Table public.${t}`,
          ok: !error,
          detail: error ? error.message : "OK",
        });
      }

      setChecks(results);
      setLoading(false);
    })();
  }, [url, key]);

  const missingTable = checks.find(
    (c) => c.name.includes("student_edit_requests") && !c.ok
  );

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Supabase Debug</h1>
          <p className="text-muted-foreground text-sm">
            Ukurasa wa utatuzi — onyesha hali ya muunganisho na schema ya database.
          </p>
        </div>

        <div className="rounded-lg border p-4 space-y-2 bg-card">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Project Ref</span>
            <code className="font-mono">{projectId || "—"}</code>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">URL</span>
            <code className="font-mono text-xs break-all">{url || "—"}</code>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Anon key</span>
            <code className="font-mono text-xs">{key ? `${key.slice(0, 12)}…${key.slice(-6)}` : "—"}</code>
          </div>
        </div>

        <div className="rounded-lg border bg-card">
          <div className="px-4 py-3 border-b font-semibold">Health checks</div>
          {loading ? (
            <div className="p-4 text-sm text-muted-foreground">Inakagua…</div>
          ) : (
            <ul className="divide-y">
              {checks.map((c, i) => (
                <li key={i} className="flex items-start justify-between gap-3 px-4 py-3 text-sm">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-block h-2.5 w-2.5 rounded-full ${
                        c.ok ? "bg-green-500" : "bg-red-500"
                      }`}
                    />
                    <span>{c.name}</span>
                  </div>
                  <code className="font-mono text-xs text-muted-foreground text-right max-w-[60%]">
                    {c.detail}
                  </code>
                </li>
              ))}
            </ul>
          )}
        </div>

        {missingTable && (
          <div className="rounded-lg border border-red-300 bg-red-50 p-4 text-sm text-red-900 space-y-2">
            <div className="font-semibold">
              ⚠️ Jedwali <code>public.student_edit_requests</code> halijaundwa kwenye database yako.
            </div>
            <p>Fungua Supabase SQL Editor ya project <code className="font-mono">{projectId}</code> na kimbiza migrations hizi mbili kwa mpangilio:</p>
            <ol className="list-decimal pl-5 space-y-1">
              <li><code>supabase/migrations/20260511063429_student_edit_requests.sql</code></li>
              <li><code>supabase/migrations/20260511081500_validate_student_edit_requests.sql</code></li>
            </ol>
            <p>Au kimbiza: <code className="font-mono">supabase db push</code> kwenye terminal ya mradi wako wa local.</p>
          </div>
        )}
      </div>
    </div>
  );
}
