import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, MapPin, CheckCircle2, Loader2, Search, Users } from "lucide-react";
import { distanceMeters, getCurrentPosition } from "@/lib/geo";
import { toast } from "sonner";

const StudentAttendance = () => {
  const [sessions, setSessions] = useState<any[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [reg, setReg] = useState("");
  const [student, setStudent] = useState<{ full_name: string; course: string | null; reg_no: string } | null>(null);
  const [searching, setSearching] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  useEffect(() => {
    supabase.from("attendance_sessions" as any).select("*")
      .eq("is_open", true).order("session_date", { ascending: false })
      .then(({ data }) => {
        const list = (data as any) || [];
        setSessions(list);
        if (list.length === 1) setActiveId(list[0].id);
      });
  }, []);

  const lookup = async () => {
    const r = reg.trim().toUpperCase();
    if (!r) return;
    setSearching(true); setStudent(null);
    const { data } = await supabase.from("group_members")
      .select("full_name, course, reg_no")
      .ilike("reg_no", r).limit(1);
    setSearching(false);
    if (!data || data.length === 0) {
      return toast.error("Reg No haijapatikana kwenye mfumo. Wasiliana na admin.");
    }
    setStudent({ ...data[0], reg_no: r });
  };

  const confirm = async () => {
    if (!student || !activeId) return;
    const session = sessions.find((s) => s.id === activeId);
    if (!session) return;
    setConfirming(true);
    try {
      let lat: number | null = null, lng: number | null = null, dist: number | null = null;
      if (session.location_required) {
        if (session.location_lat == null || session.location_lng == null) {
          throw new Error("Admin hajaweka eneo la kipindi hiki.");
        }
        const pos = await getCurrentPosition(20000);
        lat = pos.lat; lng = pos.lng;
        dist = distanceMeters(pos.lat, pos.lng, session.location_lat, session.location_lng);
        if (dist > session.location_radius_m) {
          throw new Error(`Uko mbali sana na eneo (~${Math.round(dist)}m). Lazima uwe ndani ya ${session.location_radius_m}m.`);
        }
      }
      const { error } = await supabase.from("attendance_records" as any).insert({
        session_id: activeId, reg_no: student.reg_no,
        full_name: student.full_name, course: student.course,
        lat, lng, distance_m: dist,
      });
      if (error) {
        if (error.code === "23505") throw new Error("Tayari umethibitisha kwenye kipindi hiki.");
        throw error;
      }
      setDone(session.title);
      toast.success("Umethibitisha! Asante.");
    } catch (e: any) {
      toast.error(e.message || "Imeshindikana");
    } finally {
      setConfirming(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-background grid place-items-center p-4 scene-3d">
        <Card className="p-8 max-w-md text-center shadow-elegant card-3d float-3d">
          <CheckCircle2 className="h-16 w-16 mx-auto text-accent mb-3" />
          <h1 className="text-2xl font-extrabold mb-1">Umethibitisha!</h1>
          <p className="text-muted-foreground mb-1">{student?.full_name}</p>
          <p className="text-sm text-muted-foreground mb-4">Kipindi: {done}</p>
          <Button asChild className="w-full"><Link to="/">Rudi Nyumbani</Link></Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background scene-3d">
      <div className="container py-8 max-w-xl">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="h-4 w-4" /> Nyumbani
        </Link>
        <h1 className="text-2xl font-extrabold mb-1">Udhulio (Attendance)</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Andika Reg No yako, jina na kozi yataonekana, kisha confirm ukiwa darasani / tent.
        </p>

        {sessions.length === 0 ? (
          <Card className="p-8 text-center text-muted-foreground">
            <Users className="h-10 w-10 mx-auto mb-3 opacity-40" />
            Hakuna kipindi kilichofunguliwa kwa sasa. Subiri admin awashe.
          </Card>
        ) : (
          <Card className="p-5 shadow-card space-y-4">
            <div>
              <Label>Chagua Kipindi</Label>
              <select
                value={activeId}
                onChange={(e) => setActiveId(e.target.value)}
                className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="">— chagua —</option>
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>{s.title} — {s.session_date}</option>
                ))}
              </select>
              {activeId && (() => {
                const s = sessions.find((x) => x.id === activeId);
                return s?.location_required ? (
                  <p className="text-xs text-warning mt-1 inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> GPS inahitajika — lazima uwe ndani ya {s.location_radius_m}m.
                  </p>
                ) : null;
              })()}
            </div>

            <div>
              <Label>Reg No</Label>
              <div className="flex gap-2">
                <Input
                  value={reg}
                  onChange={(e) => { setReg(e.target.value); setStudent(null); }}
                  placeholder="Mfano: ISM/123/2025"
                  onKeyDown={(e) => e.key === "Enter" && lookup()}
                />
                <Button type="button" onClick={lookup} disabled={searching || !reg.trim()}>
                  {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            {student && (
              <Card className="p-4 bg-accent/5 border-accent/30">
                <div className="text-xs uppercase tracking-widest text-muted-foreground">Taarifa zako</div>
                <div className="font-bold text-lg">{student.full_name}</div>
                <div className="text-sm text-muted-foreground">Kozi: {student.course || "—"}</div>
                <div className="text-xs font-mono-num text-muted-foreground">{student.reg_no}</div>
              </Card>
            )}

            <Button
              className="w-full"
              size="lg"
              disabled={!student || !activeId || confirming}
              onClick={confirm}
            >
              {confirming ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Inathibitisha...</> : "Confirm Attendance"}
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default StudentAttendance;
