import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Ban, Search, ShieldOff, ArrowLeft, Trash2, UserX, CheckCircle2 } from "lucide-react";
import { verifyAdmin } from "@/lib/adminAuth";

interface Student { id: string; full_name: string; exam_number: string; course: string | null; }
interface Blocked { id: string; reg_no: string; full_name: string | null; reason: string | null; created_at: string; }

const AdminBlockedStudents = () => {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Student[]>([]);
  const [searching, setSearching] = useState(false);
  const [blocked, setBlocked] = useState<Blocked[]>([]);
  const [reason, setReason] = useState("");

  useEffect(() => {
    verifyAdmin().then((a) => { if (!a) navigate("/admin/login"); else setReady(true); });
  }, [navigate]);

  const loadBlocked = async () => {
    const { data } = await supabase
      .from("blocked_students" as any)
      .select("*")
      .order("created_at", { ascending: false });
    setBlocked((data as any) || []);
  };

  useEffect(() => { if (ready) loadBlocked(); }, [ready]);

  const search = async (e: React.FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (!term) return;
    setSearching(true);
    try {
      const { data } = await supabase
        .from("students")
        .select("id, full_name, exam_number, course")
        .or(`exam_number.ilike.%${term}%,full_name.ilike.%${term}%`)
        .limit(25);
      setResults((data as any) || []);
    } finally {
      setSearching(false);
    }
  };

  const block = async (s: Student) => {
    const { error } = await supabase.from("blocked_students" as any).upsert({
      reg_no: s.exam_number,
      full_name: s.full_name,
      reason: reason.trim() || null,
    }, { onConflict: "reg_no" });
    if (error) return toast.error(error.message);
    toast.success(`🚫 ${s.full_name} amezuiwa.`);
    loadBlocked();
  };

  const unblock = async (b: Blocked) => {
    if (!confirm(`Ondoa kuzuiwa kwa ${b.full_name || b.reg_no}?`)) return;
    const { error } = await supabase.from("blocked_students" as any).delete().eq("id", b.id);
    if (error) return toast.error(error.message);
    toast.success("Amefunguliwa.");
    loadBlocked();
  };

  const isBlocked = (reg: string) => blocked.some((b) => b.reg_no.toLowerCase() === reg.toLowerCase());

  if (!ready) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-gradient-hero text-primary-foreground sticky top-0 z-40 shadow-elegant">
        <div className="container py-3 flex items-center justify-between gap-3">
          <h1 className="font-extrabold flex items-center gap-2"><ShieldOff className="h-5 w-5" /> Wanafunzi Walio Zuiwa</h1>
          <Button asChild size="sm" variant="secondary"><Link to="/admin"><ArrowLeft className="h-4 w-4 mr-1" /> Rudi</Link></Button>
        </div>
      </header>

      <div className="container py-8 grid lg:grid-cols-2 gap-6">
        <Card className="p-5 shadow-card card-3d">
          <div className="flex items-center gap-2 mb-3">
            <Search className="h-5 w-5 text-accent" />
            <h2 className="font-bold">Tafuta na uzuie mwanafunzi</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-3">Tafuta kwa Reg No au jina kutoka kwenye orodha ya wanafunzi waliojisajili. Wanaozuiwa hawataweza kuanza mtihani.</p>
          <form onSubmit={search} className="flex gap-2 mb-3">
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Reg No au jina…" />
            <Button type="submit" disabled={searching}>{searching ? "…" : "Tafuta"}</Button>
          </form>
          <div className="mb-3">
            <Label className="text-xs">Sababu (hiari)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Mfano: amefukuzwa shule" />
          </div>
          <div className="space-y-2 max-h-[400px] overflow-auto">
            {results.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-6">Hakuna matokeo bado.</p>
            )}
            {results.map((s) => {
              const blockedAlready = isBlocked(s.exam_number);
              return (
                <div key={s.id} className="flex items-center justify-between gap-2 p-2 rounded-md border border-border">
                  <div className="min-w-0">
                    <div className="font-semibold truncate">{s.full_name}</div>
                    <div className="text-xs text-muted-foreground font-mono-num">{s.exam_number} {s.course ? `· ${s.course}` : ""}</div>
                  </div>
                  {blockedAlready ? (
                    <span className="text-xs px-2 py-1 rounded-full bg-destructive/10 text-destructive font-bold">Amezuiwa</span>
                  ) : (
                    <Button size="sm" variant="destructive" onClick={() => block(s)}>
                      <Ban className="h-3.5 w-3.5 mr-1" /> Zuia
                    </Button>
                  )}
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5 shadow-card card-3d">
          <div className="flex items-center gap-2 mb-3">
            <UserX className="h-5 w-5 text-destructive" />
            <h2 className="font-bold">Orodha ya Waliozuiwa ({blocked.length})</h2>
          </div>
          <div className="space-y-2 max-h-[500px] overflow-auto">
            {blocked.length === 0 && (
              <div className="text-center py-10 text-sm text-muted-foreground">
                <CheckCircle2 className="h-10 w-10 mx-auto mb-2 text-accent opacity-60" />
                Hakuna mwanafunzi aliyezuiwa.
              </div>
            )}
            {blocked.map((b) => (
              <div key={b.id} className="flex items-center justify-between gap-2 p-3 rounded-md bg-destructive/5 border border-destructive/20">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{b.full_name || "—"}</div>
                  <div className="text-xs font-mono-num text-muted-foreground">{b.reg_no}</div>
                  {b.reason && <div className="text-xs text-muted-foreground italic mt-0.5">"{b.reason}"</div>}
                </div>
                <Button size="sm" variant="ghost" onClick={() => unblock(b)} className="text-destructive">
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminBlockedStudents;
