## Mpango wa Maboresho (Mitihani)

Nimesoma maombi yako. Kwa kuwa ni vipengele vingi vinavyogusa schema, ExamTake, na admin, naomba uthibitishe kabla sijaanza:

### 1. Kifaa kimoja kwa kila mwanafunzi (Device Lock)
- Tutaongeza jedwali jipya `exam_device_locks` (exam_id, reg_no, device_fingerprint, locked_at)
- Mwanafunzi akianza mtihani, fingerprint ya kifaa (browser+screen+UA hash) inahifadhiwa
- Akijaribu kuingia kwenye kifaa kingine kwa reg_no hiyo hiyo → anazuiwa
- Toggle kwenye admin: "Lock to one device" (kwa default: ON)

### 2. GPS kwenye mitihani yote (admin akiwasha)
- Tayari `exams.location_required/lat/lng/radius_m` zipo
- Tutaboresha `ExamInstructions` na `ExamTake` kuhakikisha GPS check inafanyika **kabla ya kuanza** kwa mitihani yote yenye `location_required=true` (sio attendance peke yake)
- Ikiwa nje ya radius → mwanafunzi anazuiwa kuingia

### 3. Matching items — randomize pande zote mbili
- Kushoto na kulia vyote vinarandomized per-student (sasa hivi kulia tu)
- Ramani sahihi (correct map) inabaki kwenye DB

### 4. Ondoa "Processing" — zero badala yake
- `AdminResults` na popote inaposomwa: kama `attempt.status != 'submitted'/'auto_submitted'/'terminated'` au hakuna attempt → onyesha **0/total** badala ya "Processing"
- Mwanafunzi asiyetuma → score = 0 publicly

### 5. Admin Emergency Form Submit
- Kwenye `AdminResults` au `AdminAttemptDetail`: kitufe "Wasilisha kwa Dharura" kwa attempts ambazo bado ni `in_progress`
- Kinabadilisha status → `auto_submitted` na kuhifadhi score ya sasa (au 0)

### 6. Camera Face Monitoring (admin akiruhusu)
- Toggle mpya `exams.camera_required boolean default false`
- Akiwasha: ExamTake inaomba camera permission, na kutumia `FaceDetector` API ya browser (au face-api.js fallback) kuangalia kila sek 3:
  - Hakuna uso → onyo
  - Nyuso 2+ → onyo + log
  - Onyo zaidi ya 3 → auto-submit kama "terminated" (violation)
- Onyo zinaonyeshwa kama toast; zinarekodiwa kwenye `attempts.violation_reason`

---

### Maswali ya kuthibitisha:
1. **Device lock**: Ikiwa mwanafunzi kifaa chake kimevunjika na anataka kifaa kipya — admin awe na kitufe cha "Reset device lock" kwa reg_no? (napendekeza ndio)
2. **Camera face**: Browser nyingi za simu hazina `FaceDetector` native. Tutumie `face-api.js` (~6MB models) ili ifanye kazi kila mahali, au tukubali ifanye kazi kwenye Chrome Android tu (nyepesi)?
3. **Emergency submit**: Score iwe 0 au ihesabiwe kutoka majibu aliyojaza tayari?

Nikipata majibu yako (au sema "endelea na default") nitajenga vyote kwa pamoja.